-- =====================================================================
-- CREAR USUARIOS DESDE LA PLATAFORMA
-- =====================================================================
-- Se puede correr varias veces sin romper nada.
--
-- QUÉ NO HACE ESTE ARCHIVO: crear la cuenta. Eso vive en auth.users y
-- solo se puede tocar con la llave de servicio, desde el servidor
-- (src/app/api/admin/usuarios/route.ts). Aquí van las dos columnas que
-- el perfil necesita y las reglas de quién puede tocarlas.
-- =====================================================================

alter table public.perfiles
  -- La clave que sugiere la plataforma es PROVISIONAL: sirve para el
  -- primer ingreso y nada más. Mientras esto esté en true, la
  -- aplicación no deja pasar a ningún módulo: obliga a cambiarla.
  --
  -- Seis dígitos son un millón de combinaciones. Como clave de un rato
  -- está bien; como clave permanente se adivina. Por eso el bloqueo no
  -- es un consejo en pantalla: es la condición para entrar.
  add column if not exists clave_provisional boolean not null default false,

  -- UN MÓDULO EXTRA PARA UNA PERSONA, sin inventarle un rol.
  --
  -- Los permisos son del ROL, y eso está bien: quince personas con el
  -- mismo trabajo se administran una vez. Pero de vez en cuando hay una
  -- excepción —el de portería que además revisa el maestro— y crear un
  -- rol "portería que además revisa el maestro" para una persona
  -- convierte la lista de roles en una lista de personas.
  --
  -- Es un mapa de ruta → nivel: {"/sider/maestro": "editar"}. Se SUMA a
  -- lo que da el rol y nunca resta: quitar un permiso se hace en el rol,
  -- que es donde se ve a quién más afecta.
  add column if not exists permisos_extra jsonb not null default '{}'::jsonb;

-- Que no entre un nivel inventado. Va en una función y no escrito
-- dentro del CHECK porque Postgres no acepta subconsultas ahí: hay que
-- recorrer el jsonb, y recorrerlo es una subconsulta. Se probó.
create or replace function public.permisos_extra_validos(p jsonb)
returns boolean
language sql
immutable
as $$
  select jsonb_typeof(p) = 'object'
     and coalesce(
           (select bool_and(e.value in ('ver', 'editar')) from jsonb_each_text(p) e),
           true)   -- un objeto vacío no tiene nada que validar
$$;

alter table public.perfiles
  drop constraint if exists perfiles_permisos_extra_validos;
alter table public.perfiles
  add constraint perfiles_permisos_extra_validos
  check (public.permisos_extra_validos(permisos_extra));

-- ---------------------------------------------------------------------
-- LAS DOS COLUMNAS NUEVAS SON DEL ADMINISTRADOR.
--
-- Sin esto, cualquiera podría darse permisos_extra desde la pantalla de
-- su propio perfil —la política de "editar mi perfil" le deja escribir
-- su fila— y ascenderse solo. El disparador de columnas protegidas ya
-- existía para rol y usuario; se le agregan estas dos.
-- ---------------------------------------------------------------------
create or replace function public.perfil_campos_protegidos()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Sin sesión no hay nadie a quien impedirle nada: es el servidor
  -- escribiendo con la llave de servicio. Ver la explicación de arriba.
  if auth.uid() is null then
    return new;
  end if;

  -- El administrador sí puede cambiarlos.
  if public.mi_rol() = 'admin' then
    return new;
  end if;

  if new.rol is distinct from old.rol
     or new.usuario is distinct from old.usuario
     or new.activo is distinct from old.activo
     or new.bodega is distinct from old.bodega then
    raise exception 'Solo el administrador puede cambiar usuario, rol, bodega o estado.';
  end if;

  -- Las dos columnas de 03-usuarios.sql se comparan por jsonb y no por
  -- nombre. Escrito como `new.permisos_extra`, esta función NO COMPILA si
  -- la columna todavía no existe, y entonces 01 y 03 tendrían que correrse
  -- en un orden exacto. Por jsonb, si la columna no está, los dos lados
  -- dan null, null no es distinto de null, y no pasa nada. Así el orden
  -- deja de importar y no hay dos copias del disparador que se pisen: era
  -- eso lo que hacía que correr 01 despues de 03 borrara la proteccion.
  if to_jsonb(new)->'permisos_extra' is distinct from to_jsonb(old)->'permisos_extra' then
    raise exception 'Solo el administrador puede cambiar los permisos.';
  end if;

  -- La clave provisional se puede APAGAR uno mismo —es lo que pasa al
  -- cambiar la contraseña— pero no prender.
  if coalesce((to_jsonb(new)->>'clave_provisional')::boolean, false)
     and not coalesce((to_jsonb(old)->>'clave_provisional')::boolean, false) then
    raise exception 'Solo el administrador puede marcar una clave como provisional.';
  end if;

  return new;
end;
$$;

-- ---------------------------------------------------------------------
-- EL ADMINISTRADOR VE Y EDITA TODOS LOS PERFILES.
-- La pantalla de usuarios necesita listarlos; sin esta política solo
-- vería el suyo y la lista saldría con una sola fila.
-- ---------------------------------------------------------------------
drop policy if exists "perfiles: el admin ve todo" on public.perfiles;
create policy "perfiles: el admin ve todo"
  on public.perfiles for select
  to authenticated
  using (public.mi_rol() = 'admin' or id = auth.uid());

drop policy if exists "perfiles: el admin edita todo" on public.perfiles;
create policy "perfiles: el admin edita todo"
  on public.perfiles for update
  to authenticated
  using (public.mi_rol() = 'admin')
  with check (public.mi_rol() = 'admin');

-- ---------------------------------------------------------------------
-- ¿ESTÁ LIBRE ESE USUARIO?
--
-- La pantalla lo pregunta ANTES de crear, para decirlo mientras se
-- escribe en vez de reventar al guardar. Va como función y no como
-- consulta directa porque quien pregunta puede no tener permiso de leer
-- la tabla entera, y para contestar "sí o no" no hace falta.
-- ---------------------------------------------------------------------
create or replace function public.usuario_libre(p_usuario text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select not exists (
    select 1 from public.perfiles
     where lower(btrim(usuario)) = lower(btrim(p_usuario))
  );
$$;

grant execute on function public.usuario_libre(text) to authenticated;
