export const hayLlaveDeServicio = () => true;
