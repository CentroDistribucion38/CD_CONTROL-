import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { usuarioActual } from "@/lib/sesion";
import { misPermisos } from "@/lib/permisos";
import { MODULOS } from "@/modulos/registro";
import { hayLlaveDeServicio } from "@/lib/supabase/servicio";
import "../roles/roles.css";
import "./usuarios.css";
import { Usuarios } from "./Usuarios";
import { Historial, type Mov } from "./Historial";

export const dynamic = "force-dynamic";

/**
 * ADMINISTRACIÓN · USUARIOS.
 *
 * Crear la cuenta, ponerle el rol, y —si hace falta— darle una pantalla
 * suelta que su rol no incluye.
 *
 * La llave de servicio se comprueba AQUÍ, antes de dibujar el formulario:
 * si no está puesta, la pantalla lo dice con los pasos exactos en vez de
 * dejar llenar todo y fallar al guardar.
 */
export default async function UsuariosPage({ searchParams }: {
  searchParams: Promise<{ q?: string }>;
}) {
  const q = (await searchParams).q ?? "";
  const permisos = await misPermisos();

  if (!permisos.manda) {
    return (
      <div className="rl">
        <section className="tarjeta">
          <div className="cab">
            <div>
              <h2>Solo lectura</h2>
              <p>
                Crear usuarios requiere un rol que administre la plataforma. El tuyo,{" "}
                <b>{permisos.nombreRol}</b>, no lo hace. <Link href="/inicio">Volver</Link>
              </p>
            </div>
          </div>
        </section>
      </div>
    );
  }

  const supabase = await createClient();
  const user = await usuarioActual();
  const [gente, roles, permisosRol, ingresoR, rastroR, histR] = await Promise.all([
    supabase
      .from("perfiles")
      .select("id, usuario, nombre, rol, activo, clave_provisional, permisos_extra")
      .order("nombre", { nullsFirst: false }),
    supabase.from("roles").select("clave, nombre, manda, descripcion").order("orden", { nullsFirst: false }),
    /* LO QUE YA DA EL ROL. Sin esto, el editor de pantallas extra se
       llena a ciegas: nadie sabe si la pantalla que está a punto de dar
       ya venía con el rol, y termina habiendo permisos sueltos que no
       hacen nada —pero que después alguien lee como si hicieran algo—.
       Es la misma tabla que lee /admin/roles; aquí solo se mira. */
    supabase.from("rol_permisos").select("rol, seccion, nivel"),
    /* LA ÚLTIMA VEZ QUE ENTRÓ Y CUÁNTO HA REGISTRADO. Si falta
       2026-09-admin-usuarios.sql no existen, y las columnas dicen «—»
       en vez de tumbar la pantalla. */
    supabase.rpc("usuarios_ingreso"),
    supabase.rpc("usuarios_rastro"),
    supabase.from("v_usuarios_historial")
      .select("id, a_quien, a_quien_nombre, a_quien_usuario, accion, detalle, hecho_nombre, hecho_en")
      .order("hecho_en", { ascending: false }).limit(400),
  ]);
  const ingresos = ingresoR.error ? null : Object.fromEntries(
    ((ingresoR.data ?? []) as { id: string; ultimo_ingreso: string | null }[]).map((r) => [r.id, r.ultimo_ingreso]));
  const registros = rastroR.error ? null : Object.fromEntries(
    ((rastroR.data ?? []) as { id: string; registros: number }[]).map((r) => [r.id, Number(r.registros)]));

  /* Si falta 03-usuarios.sql, las dos columnas nuevas no vienen. La
     pantalla lo dice y no se dibuja a medias. */
  const faltaSql = !!gente.error;

  /* El catálogo de pantallas sale del REGISTRO, que es la única lista
     que existe: una sección nueva aparece aquí sola el día que se cree. */
  const catalogo = MODULOS.filter((m) => m.activo).map((m) => ({
    id: m.id,
    nombre: m.nombre,
    acento: m.acento,
    secciones: m.secciones.map((s) => ({ nombre: s.nombre, ruta: s.ruta })),
  }));

  return (
    <div className="rl us">
      <div className="cabeza">
        <div>
          <p className="ojo">PLATAFORMA · ADMINISTRACIÓN</p>
          <h1>Usuarios</h1>
          <p className="sub">
            Crear la cuenta, ponerle el rol y, si hace falta, darle una pantalla
            que su rol no incluye. Los permisos de fondo se editan en{" "}
            <Link href="/admin/roles">Roles</Link>, que es donde se ve a quién más
            afectan.
          </p>
        </div>
      </div>

      {faltaSql ? (
        <section className="sin-tablas">
          <h2>Falta correr un archivo en Supabase</h2>
          <p>
            Ejecuta <code>supabase/03-usuarios.sql</code> en el SQL Editor. Agrega dos
            columnas al perfil: la marca de clave provisional y los permisos sueltos de
            una persona. Se puede correr varias veces sin romper nada.
          </p>
        </section>
      ) : (
        <Usuarios
          gente={(gente.data ?? []) as never[]}
          roles={(roles.data ?? []) as never[]}
          delRol={(permisosRol.data ?? []) as never[]}
          catalogo={catalogo}
          hayLlave={hayLlaveDeServicio()}
          yo={user?.id ?? ""}
          ingresos={ingresos}
          registros={registros}
          buscar={q}
        />
      )}
      {!faltaSql && (
        <Historial movs={(histR.data ?? []) as Mov[]} falta={!!histR.error}
          roles={Object.fromEntries(((roles.data ?? []) as { clave: string; nombre: string }[]).map((r) => [r.clave, r.nombre]))} />
      )}
    </div>
  );
}
