import { createClient } from "@/lib/supabase/server";
import { usuarioActual } from "@/lib/sesion";
import { misPermisos } from "@/lib/permisos";
import {
  novedadesSider, motivosNovedad, viajesEnTransito, nombresTodos, hiloNovedades,
} from "@/modulos/sider/datos";
import "../sider.css";
import { Novedades } from "./Novedades";

export const dynamic = "force-dynamic";

/**
 * NOVEDADES DE T1 / T2 — la bandeja de lo que sale mal.
 *
 * Las cuatro consultas van en paralelo: en serie, la pantalla tarda lo
 * que suman y aquí ninguna depende de la anterior.
 */
export default async function NovedadesPage() {
  const supabase = await createClient();
  const user = await usuarioActual();

  const [permisos, novedades, motivos, viajes, nombres, { data: p }] = await Promise.all([
    misPermisos(),
    novedadesSider(),
    motivosNovedad(),
    /* Los que van en camino: son los que pueden tener una novedad HOY.
       Para uno ya recibido se escribe la placa a mano, que es el mismo
       camino de T2. */
    viajesEnTransito(),
    /* Los nombres de quien reportó, quien cerró y quien respondió, de una
       sola vez: uno por fila serían cuatrocientas consultas para pintar
       una lista. Van en esta tanda y no después porque se traen todos, y
       para eso no hace falta saber primero quiénes son. */
    nombresTodos(),
    /* Desde dónde contesta esta persona. Se propone del perfil y se puede
       corregir en el formulario: alguien de Galapa que entra a responder
       no debería tener que escribir "CD Galapa" cada vez. */
    supabase.from("perfiles").select("bodega").eq("id", user!.id).maybeSingle(),
  ]);

  const puedeEditar = permisos.puedeEditar("/sider/novedades");

  /* La única que SÍ tiene que esperar: para pedir el hilo hay que saber
     de cuáles novedades, y eso lo dice la consulta de arriba. */
  const hilo = await hiloNovedades(novedades.map((n) => n.id));

  return (
    <div className="sd">
      <section className="cabeza">
        <div className="texto">
          <p className="ojo">T1 / T2 · NOVEDADES</p>
          <h1>Lo que salió mal</h1>
          <p className="sub">
            Sello roto, faltante, cliente cerrado, vehículo varado. Se reporta con
            su motivo, se mira, y se cierra diciendo qué se hizo.
          </p>
        </div>
      </section>

      <Novedades
        novedades={novedades}
        motivos={motivos}
        /* Se pasan también factura, lote y SKU: al escoger el viaje, el
           formulario los copia para no teclear tres campos que ya están
           en la base. */
        viajes={viajes.viajes.map((v) => ({
          id: v.id, placa: v.placa, cd_origen: v.cd_origen, descripcion: v.descripcion,
          sku: v.sku ?? null, factura: v.factura ?? null, lote: v.lote ?? null,
        }))}
        hilo={hilo}
        nombres={nombres}
        puedeEditar={puedeEditar}
        miBodega={String(p?.bodega ?? "")}
      />
    </div>
  );
}
