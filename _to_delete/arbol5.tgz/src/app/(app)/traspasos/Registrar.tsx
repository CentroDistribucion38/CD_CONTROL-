"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useAvisos } from "@/components/Aviso";
import type { PlacaM, Punto, TipoViaje, Viaje } from "@/modulos/traspasos/datos";
import { TURNOS, hora, quien, placaClave, type Cedula } from "@/modulos/traspasos/formato";
import { Desplegable } from "./comunes";

const nf = new Intl.NumberFormat("es-CO", { maximumFractionDigits: 0 });

/**
 * REGISTRAR UN VIAJE.
 *
 * Es la pantalla del supervisor, de pie al lado del vehículo, con el
 * celular en una mano. Todo cabe sin desplazar, y LO QUE MÁS SE REPITE
 * YA ESTÁ DE UN TOQUE: las placas que pasaron esta semana, las rutas
 * que más se usan, el turno que va por la hora. Casi ningún viaje
 * obliga a teclear nada.
 *
 * Esas listas salen de lo que ya está registrado —no hay un maestro de
 * placas ni de rutas que alguien tenga que llenar—, así que funcionan
 * desde el primer día y se afinan solas.
 *
 * NO PIDE EL "CUMPLIDO" POR NINGÚN LADO, y eso es el punto del módulo:
 * registrar este viaje ES el cumplimiento.
 *
 * DOS COSAS QUE NO SE MEZCLAN. Un viaje CON CARGA lleva placa, ruta y
 * tipo. Los VACÍOS son un número de viajes del turno y ya: no llevan
 * tipo ni placa porque no los tienen, y pedirlos obligaría a
 * inventarlos.
 *
 * EL TIPO SE ESCOGE DEL PLAN, no de una lista de nueve. Lo que hay que
 * mover en este turno ya está decidido; la pregunta de quien está al
 * lado del vehículo es «de lo que falta, cuál es este viaje». Cada
 * tipo del plan dice CUÁNTOS FALTAN, que es la cifra que se usa —«4 de
 * 7» obliga a restar—. Lo que no estaba planeado no desaparece: vive
 * detrás del «+», y queda dicho en la pantalla que va como adicional.
 */
export type PlanTipo = {
  tipo: string; nombre: string; planeado: number; cumplido: number;
};

export function Registrar({ tipos, puntos, placas, placasM,
                            vidrio = [], faltaVidrio = false,
                            fecha, turnoSugerido,
                            planTurno, hechosTurno, planPorTipo, viajes, nombres }: {
  tipos: TipoViaje[];
  puntos: Punto[];
  placas: { placa: string; veces: number }[];
  /** El maestro de placas. Lo que se puede escoger, ya no texto libre. */
  placasM: PlacaM[];
  /** EL VIDRIO PESADO QUE ESTÁ ESPERANDO CAMIÓN. Se ofrece al escoger
   *  un tipo de tolvas: quien registra ya sabe que va a cargar vidrio, y
   *  la placa y la cantidad salen del pesaje en vez de tecleárselas. */
  vidrio?: Cedula[];
  /** La migración del vidrio todavía no se ha corrido en esta base. */
  faltaVidrio?: boolean;
  fecha: string;
  turnoSugerido: string;
  /** Cuántos viajes lleva planeados el turno escogido, y cuántos van. */
  planTurno: Record<string, number>;
  hechosTurno: Record<string, number>;
  /** El plan del turno, tipo por tipo: qué falta de cada uno. */
  planPorTipo: Record<string, PlanTipo[]>;
  viajes: Viaje[];
  nombres: Record<string, string>;
}) {
  const router = useRouter();
  const supabase = createClient();
  const [avisar, avisos] = useAvisos();

  const [modo, setModo] = useState<"carga" | "vacio">("carga");
  const [turno, setTurno] = useState(turnoSugerido);
  /* VARIOS TIPOS A LA VEZ, cada uno con su cantidad.

     UN CAMIÓN PUEDE SALIR CON CASCO Y ESTIBAS, y hasta hoy había que
     escoger uno de los dos: el otro desaparecía del plan. No se podía
     registrar dos veces porque el documento es UNO —el del papel que va
     con el vehículo— y no se puede repetir.

     Se guarda como Map y no como lista para que escoger y desescoger
     sea una sola operación, y para que la cantidad de un tipo no se
     pierda al desescoger el de al lado. */
  const [tipos_, setTipos] = useState<Map<string, string>>(new Map());
  const [placa, setPlaca] = useState("");
  const [origen, setOrigen] = useState("");
  const [destino, setDestino] = useState("");
  const [viajesN, setViajesN] = useState(1);
  /* ¿ES DE ARENOSA? Solo sale con los tipos que lo piden —estibas—, y
     hasta que no se conteste no se registra: de esa respuesta depende
     que el viaje cuente en el % de cumplimiento. */
  const [arenosa, setArenosa] = useState<boolean | null>(null);
  /* LA CANTIDAD YA NO ES UNA SOLA: va por tipo, dentro de `tipos_`. La
     del PRIMER tipo se guarda además en la columna `carga` del viaje
     —lo hace la base— para que todo lo que ya la lee siga leyéndola. */
  const [nota, setNota] = useState("");
  const [mandando, setMandando] = useState(false);
  const [verOtros, setVerOtros] = useState(false);
  const [placaNueva, setPlacaNueva] = useState<string | null>(null);
  /* LA CÉDULA ESCOGIDA. El viaje nace amarrado a ella: no hay que
     acordarse de nada después, y facturación solo pone el documento. */
  const [cedula, setCedula] = useState<Cedula | null>(null);
  const [bodegaNueva, setBodegaNueva] = useState<{ lado: "o" | "d"; texto: string } | null>(null);
  const campoPlaca = useRef<HTMLButtonElement>(null);

  const hayMaestro = puntos.length > 0;
  const puntosVivos = puntos.filter((p) => p.activo);

  /* LAS BODEGAS SON UNA SOLA LISTA. La misma es origen unas veces y
     destino otras, así que no hay dos maestros ni una lista de pares:
     hay bodegas, y un viaje escoge dos. */
  const bodegas = puntosVivos.map((p) => ({
    valor: p.clave, texto: p.nombre, nota: p.descripcion,
  }));

  /* ------------------------------------------------------------------
     AGREGAR SOBRE LA MARCHA.

     El desplegable trae un «＋». Nadie se queda parado en el muelle
     esperando a que alguien con permiso entre al Maestro — y lo que se
     agrega así es exactamente lo que de verdad se usa.
     ------------------------------------------------------------------ */
  async function guardarPlacaNueva() {
    const t = (placaNueva ?? "").trim();
    if (!t) return;
    setMandando(true);
    const { data, error } = await supabase.rpc("traspaso_agregar_placa",
      { p_placa: t, p_nota: null });
    setMandando(false);
    if (error) { avisar.mal(mensajeFalta(error.message)); return }
    setPlaca(data as string);
    setPlacaNueva(null);
    avisar.bien(`${data} quedó en el maestro de placas.`);
    router.refresh();
  }

  async function guardarBodegaNueva() {
    const b = bodegaNueva;
    const t = (b?.texto ?? "").trim();
    if (!b || !t) return;
    setMandando(true);
    const { data, error } = await supabase.rpc("traspaso_agregar_punto",
      { p_nombre: t, p_descripcion: null });
    setMandando(false);
    if (error) {
      avisar.mal(/does not exist|could not find the function|schema cache/i.test(error.message)
        ? "Falta correr supabase/migraciones/2026-09-traspasos-maestro.sql en Supabase."
        : error.message);
      return;
    }
    const cl = (data as { clave: string }[] | null)?.[0]?.clave ?? "";
    if (b.lado === "o") setOrigen(cl); else setDestino(cl);
    setBodegaNueva(null);
    avisar.bien(`${t} quedó en el maestro de bodegas.`);
    router.refresh();
  }

  function mensajeFalta(m: string) {
    return /does not exist|could not find the function|schema cache/i.test(m)
      ? "Falta correr supabase/migraciones/2026-09-traspasos-placas-rutas.sql en Supabase."
      : m;
  }

  /* ------------------------------------------------------------------
     LO PLANEADO Y LO DEMÁS.

     `delPlan` son los tipos que este turno prometió mover. `otros` es
     todo lo que existe en el maestro y no está en el plan: se puede
     registrar igual —el plan no es una reja— pero detrás del «+», para
     que el camino corto sea el del plan.
     ------------------------------------------------------------------ */
  const delPlan = planPorTipo[turno] ?? [];
  const enPlan = new Set(delPlan.map((p) => p.tipo));
  const otros = tipos.filter((t) => !enPlan.has(t.clave));
  const hayPlan = delPlan.length > 0;

  /* EL ORDEN EN QUE SE ESCOGIERON. El primero es el que queda como tipo
     del viaje, así que no puede depender de cómo esté ordenado el
     maestro: es el que la persona tocó primero. */
  const escogidos = [...tipos_.keys()];
  const nombreTipo = (c: string) =>
    tipos.find((t) => t.clave === c)?.nombre ?? c;

  /* LAS DOS REGLAS DEL CUMPLIMIENTO, que vienen del maestro de tipos:
     unos tipos no miden (tolvas de vidrio) y otros solo miden si el
     viaje es de Arenosa (estibas). */
  const pideArenosa = escogidos.some((c) => tipos.find((t) => t.clave === c)?.pregunta_arenosa);
  const noMiden = escogidos.filter((c) => tipos.find((t) => t.clave === c)?.cuenta_plan === false);

  /* CUÁLES DE LOS TIPOS ESCOGIDOS SE SALEN DEL PLAN.
     Cada tipo avanza SU plan, así que la cuenta es por tipo: uno puede
     ir dentro del plan y el de al lado por encima, en el mismo viaje.
     Antes era una sola cifra porque había un solo tipo. */
  const fueraDelPlan = escogidos.filter((c) => {
    if (!hayPlan) return true;
    const l = delPlan.find((p) => p.tipo === c);
    return !l || l.planeado - l.cumplido <= 0;
  });
  /* UN VACÍO NO LLEVA DOCUMENTO. No es un olvido: es un número de
     viajes del turno, no un traslado con papel. Pedírselo obligaría a
     inventar un número, y un número inventado en una columna que no se
     puede repetir bloquea el día que alguien lo vuelva a inventar. */
  const puedeMandar = modo === "vacio"
    ? viajesN >= 1
    : escogidos.length > 0 && placa.trim() !== ""
      && origen.trim() !== "" && destino.trim() !== ""
      && (!pideArenosa || arenosa !== null);

  /* CTRL+ENTER MANDA. Quien registra veinte viajes seguidos desde el
     escritorio no quiere soltar el teclado para buscar el botón. */
  /* Si se quita el tipo que preguntaba, la respuesta sobra: dejarla
     puesta marcaría «de Arenosa» un viaje que ya no lleva estibas. */
  useEffect(() => { if (!pideArenosa && arenosa !== null) setArenosa(null) }, [pideArenosa, arenosa]);

  useEffect(() => {
    const t = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && puedeMandar && !mandando) {
        e.preventDefault(); mandar();
      }
    };
    window.addEventListener("keydown", t);
    return () => window.removeEventListener("keydown", t);
  });

  /* Escoger y desescoger un tipo. La cantidad de los demás no se toca:
     quien ya escribió «120 canastas de PET» y se equivocó de segundo
     tipo no tiene por qué volver a teclear lo primero. */
  function tocarTipo(clave: string) {
    setTipos((m) => {
      const n = new Map(m);
      if (n.has(clave)) n.delete(clave); else n.set(clave, "");
      return n;
    });
  }
  /* ------------------------------------------------------------------
     EL VIDRIO, CUANDO EL TIPO LO LLEVA

     LO DICE EL MAESTRO, NO EL NOMBRE. Antes se miraba si el nombre del
     tipo contenía la palabra «tolva», y eso estuvo mal desde el primer
     día: «que esas tolvas solo le aparezcan a TOLVAS, no a CASCO DE
     VIDRIO». El nombre se edita desde el Maestro sin que nadie sepa que
     esa palabra decide algo, y mañana puede haber «Casco vidrio
     (tolvas)» o «Tolvas de PET». Ahora es una casilla del tipo.

     SI LA MIGRACIÓN NO SE HA CORRIDO, la columna no existe y `tipos`
     llega sin ella. Ahí —y SOLO ahí— se cae al criterio viejo: es peor
     que la casilla, pero es lo que había, y dejar la pantalla sin el
     bloque sería quitarle algo que hoy funciona a quien todavía no ha
     corrido el SQL.
     ------------------------------------------------------------------ */
  const hayCasilla = tipos.some((t) => t.lleva_vidrio !== undefined);
  const llevaVidrio = (clave: string) => {
    const t = tipos.find((x) => x.clave === clave);
    if (hayCasilla) return t?.lleva_vidrio === true;
    return (t?.nombre ?? clave).toLowerCase().includes("tolva");
  };
  const esDeTolvas = escogidos.some(llevaVidrio);

  /* Si ya hay placa escogida, solo el vidrio de ESA placa: ofrecer el de
     otra sería ofrecer cargar vidrio ajeno. Sin placa, todo lo que
     espera — y escoger uno pone su placa. */
  const vidrioOfrecido = placa
    ? vidrio.filter((c) => placaClave(c.placa) === placaClave(placa))
    : vidrio;

  /* AL ESCOGER LA CÉDULA SE PONEN LA PLACA Y LA CANTIDAD.
     La cantidad es el número de tolvas pesadas: es lo que el camión
     lleva, y tecleárselo a mano al lado de un número que la báscula ya
     sabe es pedir que alguien se equivoque. Queda corregible. */
  function escogerCedula(c: Cedula) {
    setCedula(c);
    setPlaca(c.placa);
    setTipos((m) => {
      const n = new Map(m);
      for (const clave of escogidos) {
        if (llevaVidrio(clave)) n.set(clave, String(c.tolvas));
      }
      return n;
    });
  }

  /* Y SE SUELTA SOLA SI CAMBIA LA PLACA O SE QUITA EL TIPO. Una cédula
     que se queda pegada a un viaje que ya no es el suyo se manda a la
     base y la base la rechaza — un error que la pantalla pudo evitar. */
  useEffect(() => {
    if (!cedula) return;
    if (!esDeTolvas || (placa && placaClave(placa) !== placaClave(cedula.placa))) setCedula(null);
  }, [cedula, esDeTolvas, placa]);

  function ponCantidad(clave: string, v: string) {
    setTipos((m) => new Map(m).set(clave, v.replace(/\D/g, "")));
  }
  async function mandar() {
    setMandando(true);
    const esVacio = modo === "vacio";
    /* DOS PUERTAS, Y CADA UNA ES LA SUYA.
       El vacío sigue por `traspaso_registrar`: no lleva tipo ni placa ni
       documento, es un número de viajes del turno, y meterlo por la
       función de varios tipos obligaría a inventarle un tipo.
       El viaje con carga va por `traspaso_registrar_varios`, que cuelga
       los tipos y fuerza el viaje en 1 — un vehículo es un viaje. */
    const { data, error } = esVacio
      ? await supabase.rpc("traspaso_registrar", {
          p_fecha: fecha, p_turno: turno,
          p_tipo: null, p_placa: null, p_origen: null, p_destino: null,
          p_viajes: viajesN, p_vacio: true,
          p_carga: null, p_unidad: null,
          p_nota: nota.trim() || null, p_documento: null,
        })
      : await supabase.rpc("traspaso_registrar_varios", {
          p_fecha: fecha, p_turno: turno,
          p_tipos: escogidos.map((c) => ({
            tipo: c,
            cantidad: (tipos_.get(c) ?? "").trim() === "" ? null : Number(tipos_.get(c)),
          })),
          p_placa: placa,
          p_origen: origen,
          p_destino: destino,
          /* SIN ORDEN DE CARGUE: «en el registro de traspaso elimina
             orden de cargue». El número que cuenta lo pone facturación. */
          p_documento: null,
          p_nota: nota.trim() || null,
          p_arenosa: pideArenosa ? arenosa === true : false,
        });
    if (error) { setMandando(false); avisar.mal(mensajeRegistro(error.message)); return }

    /* ------------------------------------------------------------------
       Y SE AMARRA LA CÉDULA, si se escogió.

       VA EN UNA LLAMADA APARTE y no como un argumento más de registrar:
       esa función tiene cuatrocientas líneas de reglas acumuladas —el
       día operativo, el tope de siete días, el candado del día cerrado—
       y en PostgreSQL no se remienda el cuerpo de una función; para
       agregarle un argumento hay que reescribirla entera. Ya se han
       perdido reglas reescribiéndola.

       SI EL AMARRE FALLA, EL VIAJE YA EXISTE Y ESO ESTÁ BIEN: el viaje
       ocurrió. Se dice lo que pasó y con qué cédula, para poder
       amarrarla después, en vez de dejar creer que no se registró nada.
       ------------------------------------------------------------------ */
    let avisoVidrio = "";
    const fila = Array.isArray(data) ? data[0] : data;
    const idViaje = (fila as { id?: string } | null)?.id;
    if (cedula && idViaje) {
      const r = await supabase.rpc("traspaso_amarrar_cedula", {
        p_viaje: idViaje, p_cedula: cedula.id,
      });
      avisoVidrio = r.error
        ? ` · OJO: el viaje quedó registrado pero la cédula ${cedula.cedula} NO se amarró (${r.error.message})`
        : ` · lleva la cédula ${cedula.cedula} con ${cedula.tolvas} tolva${cedula.tolvas === 1 ? "" : "s"}`;
      if (r.error) avisar.mal(`El viaje se registró, pero la cédula ${cedula.cedula} no quedó amarrada: ${r.error.message}`);
    }

    setMandando(false);

    const cuantos = escogidos.length;
    avisar.bien(esVacio
      ? `${viajesN} viaje${viajesN === 1 ? "" : "s"} vacío${viajesN === 1 ? "" : "s"} en el turno ${turno}.`
      /* SE DICE CUÁNTOS PLANES MOVIÓ, no «un viaje». Un camión con tres
         tipos avanza tres planes, y el total del turno va a subir tres:
         quien lo registró tiene que saberlo en el momento, no
         descubrirlo en Control preguntándose de dónde salieron. */
      : fueraDelPlan.length === 0
        ? `${placa.toUpperCase()} registrado · ${cuantos} tipo${cuantos === 1 ? "" : "s"}. El plan del turno ya lo cuenta.${avisoVidrio}`
        : fueraDelPlan.length === cuantos
          ? `${placa.toUpperCase()} registrado · ${cuantos} tipo${cuantos === 1 ? "" : "s"}, ${cuantos === 1 ? "fuera del plan" : "todos fuera del plan"}. Va a salir en Control por encima.${avisoVidrio}`
          : `${placa.toUpperCase()} registrado · ${cuantos - fueraDelPlan.length} del plan y ${fueraDelPlan.length} por encima.${avisoVidrio}`);

    /* SE LIMPIA LO DEL VIAJE Y SE DEJA LO DEL TURNO: quien registra
       varios seguidos del mismo tipo y la misma ruta no debería volver
       a escogerlos cada vez — es lo que hace que se dejen de registrar
       a media tarde. */
    setPlaca(""); setNota(""); setViajesN(1); setCedula(null);
    /* LOS TIPOS TAMBIÉN SE LIMPIAN. Se quedaban puestos «porque el
       siguiente suele ser igual», y con varios tipos eso es otra cosa:
       un camión de casco registrado detrás de uno de casco+estibas+PET
       avanzaría tres planes sin que nadie lo tocara. */
    setTipos(new Map()); setArenosa(null);
    campoPlaca.current?.focus();
    router.refresh();
  }

  /* El índice único habla en su idioma. Quien está de pie al lado de un
     camión no tiene por qué leer «duplicate key value violates unique
     constraint». La base ya manda el mensaje bueno cuando puede; esto
     cubre el caso en que llegue el crudo. */
  function mensajeRegistro(m: string) {
    if (/does not exist|could not find the function|schema cache/i.test(m)) {
      return "Falta correr supabase/migraciones/2026-09-traspasos-documento.sql en Supabase.";
    }
    /* SI LA BASE TODAVÍA PIDE LA ORDEN DE CARGUE es que falta correr
       el archivo que la quita: se dice cuál, no «hay que decir el
       documento», que ya no se puede poner en esta pantalla. */
    if (/Hay que decir el documento/i.test(m)) {
      return "Falta correr supabase/migraciones/2026-09-traspasos-sin-orden-cargue.sql en Supabase.";
    }
    /* Y SI LA BASE TODAVÍA RECHAZA MAÑANA, la pantalla y la base se
       separaron: aquí ya se deja escoger el día siguiente. Decirlo así
       ahorra la llamada preguntando por qué el botón deja pero el
       guardado no. */
    if (/todavía no ha pasado/i.test(m)) {
      return "Falta correr supabase/migraciones/2026-09-traspasos-registro-adelantado.sql en Supabase.";
    }
    return m;
  }

  const plan = planTurno[turno] ?? 0;
  const hechos = hechosTurno[turno] ?? 0;

  return (
    <>
      {avisos}
      <div className="consola">
        <section className="tarj-reg">
          <div className="cab">
            <h2>Viaje nuevo</h2>
            <p>Todo cabe en una pantalla. Lo que más se repite ya está de un toque.</p>
          </div>

          <div className="cuerpo-f">
            <div className="linea-campos">
              <div>
                <span className="rot-campo">¿Qué se registra?</span>
                <div className="seg">
                  <button type="button" className={modo === "carga" ? "on" : ""}
                          onClick={() => setModo("carga")}>Viaje con carga</button>
                  <button type="button" className={modo === "vacio" ? "on" : ""}
                          onClick={() => setModo("vacio")}>Viaje vacío</button>
                </div>
              </div>
              <div>
                <span className="rot-campo">Turno</span>
                <div className="seg turno">
                  {TURNOS.map((t) => (
                    <button key={t} type="button" className={turno === t ? "on" : ""}
                            onClick={() => setTurno(t)}>{t}</button>
                  ))}
                </div>
              </div>
            </div>

            {modo === "carga" && (
              <>
                {/* SIN ORDEN DE CARGUE: «en el registro de traspaso elimina
                    orden de cargue». El patio registra placa, tipo y ruta;
                    el número del viaje lo pone facturación al confirmar la
                    salida, y es ese el que se cruza con SAP. */}
                {/* ─ EL VIDRIO QUE ESTÁ ESPERANDO CAMIÓN ─

                    «Coloqué tolva y no veo qué placas tengo allí con
                     tolva y la cantidad. Eso viene del registro de
                     salida.»

                    VA ARRIBA DE LA PLACA, y ese es el punto entero: si
                    fuera abajo, la placa ya estaría escrita a mano y
                    esto sería una comprobación. Arriba es la forma de
                    escogerla — se toca la cédula y quedan puestas la
                    placa Y la cantidad de tolvas.

                    SOLO CUANDO EL VIAJE ES DE TOLVAS. En los demás no
                    tiene nada que decir, y un bloque que sale siempre
                    deja de leerse. */}
                {esDeTolvas && (
                  <div className="tp-vidrio">
                    {faltaVidrio ? (
                      <p className="tp-vidrio-falta">
                        Falta correr <code>2026-09-vidrio-cedula-facturacion.sql</code> en
                        Supabase para poder amarrar el vidrio al viaje. Mientras tanto se
                        registra como siempre.
                      </p>
                    ) : vidrioOfrecido.length === 0 ? (
                      <p className="tp-vidrio-falta">
                        {placa
                          ? <>La placa <b>{placa}</b> no tiene vidrio pesado esperando. Si acaba de
                              pesarse, quien pesó tiene que <b>cerrar</b> la salida en
                              Quiebra → Salida → Pesar.</>
                          : <>No hay vidrio pesado esperando camión. Se pesa y se cierra en
                              Quiebra → Salida → Pesar, y aquí aparece solo.</>}
                      </p>
                    ) : (
                      <>
                        <p className="tp-vidrio-ojo">
                          VIDRIO PESADO ESPERANDO CAMIÓN
                          <span> · toca una y se ponen la placa y las tolvas</span>
                        </p>
                        <ul className="tp-vidrio-lista">
                          {vidrioOfrecido.map((c) => (
                            <li key={c.id}>
                              <button type="button"
                                      className={cedula?.id === c.id ? "on" : ""}
                                      aria-pressed={cedula?.id === c.id}
                                      onClick={() => cedula?.id === c.id ? setCedula(null) : escogerCedula(c)}>
                                <b>{c.placa}</b>
                                <span>{c.tolvas} tolva{c.tolvas === 1 ? "" : "s"}</span>
                                <em>{c.cedula} · {nf.format(c.neto_kg)} kg
                                  {c.dias_esperando > 0 && ` · ${c.dias_esperando} d`}</em>
                              </button>
                            </li>
                          ))}
                        </ul>
                        {cedula && (
                          <p className="tp-vidrio-puesta">
                            Este viaje va a llevar la cédula <b>{cedula.cedula}</b> —{" "}
                            {cedula.tolvas} tolva{cedula.tolvas === 1 ? "" : "s"},{" "}
                            {nf.format(cedula.neto_kg)} kg. Facturación ya no tiene que
                            escogerla: solo pone el documento.
                          </p>
                        )}
                      </>
                    )}
                  </div>
                )}

                <div>
                  <span className="rot-campo">Placa</span>
                  {/* DE LISTA, NO A MANO. Las placas salen del maestro: una
                      equivocación tecleada una vez ya no entra en la lista
                      ni se vuelve a ofrecer. El «＋» está al lado para que
                      un vehículo nuevo no trabe el registro. */}
                  <div className="placa">
                    <Desplegable grande disparoRef={campoPlaca} valor={placa}
                                 ariaLabel="Placa del vehículo" vacio="Escoge la placa…"
                                 opciones={placasM.map((p) => ({
                                   valor: p.placa, texto: p.placa, nota: p.nota,
                                 }))}
                                 extra="Otra placa…"
                                 alEscoger={setPlaca}
                                 alExtra={() => setPlacaNueva("")} />
                  </div>

                  {placaNueva !== null && (
                    <div className="alta">
                      {/* MAYÚSCULA DESDE LA TECLA. La base ya la sube al
                          guardar —upper() en traspaso_agregar_placa— pero
                          quien teclea «nlw428» vería una cosa en la
                          pantalla y otra en la lista de abajo, y la
                          primera pregunta sería si se guardó bien. */}
                      <input value={placaNueva} autoFocus autoComplete="off" spellCheck={false}
                             placeholder="ABC123" aria-label="Placa nueva"
                             onChange={(e) => setPlacaNueva(e.target.value.toUpperCase())}
                             onKeyDown={(e) => {
                               if (e.key === "Enter") { e.preventDefault(); guardarPlacaNueva() }
                               if (e.key === "Escape") setPlacaNueva(null);
                             }} />
                      <button type="button" className="btn si chico" disabled={mandando}
                              onClick={guardarPlacaNueva}>Agregar</button>
                      <button type="button" className="btn chico"
                              onClick={() => setPlacaNueva(null)}>Dejar así</button>
                    </div>
                  )}
                  {/* LAS PLACAS DE LA SEMANA. Casi siempre el vehículo
                      que está en la puerta ya pasó: tocarla es un gesto,
                      teclearla con guantes son diez segundos y un error
                      de dedo. */}
                  {placas.length > 0 && (
                    <div className="recientes">
                      {placas.map((p) => (
                        <button key={p.placa} type="button"
                                onClick={() => setPlaca(p.placa)}>{p.placa}</button>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <span className="rot-campo">
                    {hayPlan ? `Del plan del turno ${turno}` : "Tipo de viaje"}
                  </span>

                  {hayPlan ? (
                    <>
                      <div className="chips-plan">
                        {delPlan.map((p) => {
                          const f = Math.max(0, p.planeado - p.cumplido);
                          const sobra = Math.max(0, p.cumplido - p.planeado);
                          return (
                            <button key={p.tipo} type="button"
                                    className={"chip-plan"
                                      + (tipos_.has(p.tipo) ? " on" : "")
                                      + (f === 0 ? " lleno" : "")}
                                    aria-pressed={tipos_.has(p.tipo)}
                                    onClick={() => tocarTipo(p.tipo)}>
                              <b>{p.nombre}</b>
                              <span className="falta">
                                {f > 0 ? `Faltan ${f}`
                                  : sobra > 0 ? `+${sobra} sobre el plan`
                                  : "Completo"}
                              </span>
                              <span className="prog">{p.cumplido} / {p.planeado}</span>
                            </button>
                          );
                        })}

                        {/* LO QUE NO ESTABA PLANEADO. El plan no es una
                            reja: si llegó un viaje de algo que nadie
                            previó, se registra —y Control lo va a
                            mostrar como «sin planear», que es
                            justamente el dato que sirve—. */}
                        {otros.length > 0 && (
                          <button type="button"
                                  className={"chip-mas" + (verOtros ? " on" : "")}
                                  aria-expanded={verOtros}
                                  onClick={() => setVerOtros((v) => !v)}>
                            <b>+</b>
                            <span className="falta">Adicional</span>
                            <span className="prog">fuera del plan</span>
                          </button>
                        )}
                      </div>

                      {verOtros && (
                        <div className="chips otros-tipos">
                          {otros.map((t) => (
                            <button key={t.clave} type="button"
                                    className={tipos_.has(t.clave) ? "on" : ""}
                                    aria-pressed={tipos_.has(t.clave)}
                                    onClick={() => tocarTipo(t.clave)}>{t.nombre}</button>
                          ))}
                        </div>
                      )}

                      {/* SE DICE ANTES DE REGISTRAR, no después. Que un
                          viaje salga por encima del plan no es un error
                          —pasa todos los días— pero sí es algo que quien
                          lo registra tiene que saber que está haciendo. */}
                      {fueraDelPlan.length > 0 && (
                        <p className="guia adicional">
                          {fueraDelPlan.length === 1
                            ? <><b>{nombreTipo(fueraDelPlan[0])}</b> va como <b>adicional</b>: ya completó su plan del turno o no estaba en él.</>
                            : <>Van como <b>adicionales</b>: {fueraDelPlan.map(nombreTipo).join(", ")}. Ya completaron su plan del turno o no estaban en él.</>}
                        </p>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="chips">
                        {tipos.map((t) => (
                          <button key={t.clave} type="button"
                                  className={tipos_.has(t.clave) ? "on" : ""}
                                  aria-pressed={tipos_.has(t.clave)}
                                  onClick={() => tocarTipo(t.clave)}>{t.nombre}</button>
                        ))}
                      </div>
                      <p className="guia" style={{ marginTop: 10 }}>
                        El turno {turno} no tiene plan publicado, así que se escoge de la lista
                        completa. Todo lo que se registre va a salir como «sin planear» en Control.
                      </p>
                    </>
                  )}
                </div>

                {/* ¿ES DE ARENOSA? Va pegado a los tipos porque es parte
                    de escoger el tipo: de esta respuesta depende que el
                    viaje cuente en el % de cumplimiento. */}
                {pideArenosa && (
                  <div>
                    <span className="rot-campo">
                      ¿{escogidos.filter((c) => tipos.find((t) => t.clave === c)?.pregunta_arenosa).map(nombreTipo).join(" y ")} de o para Arenosa?
                    </span>
                    <div className="chips tr-arenosa">
                      <button type="button" className={arenosa === true ? "on" : ""}
                              aria-pressed={arenosa === true} onClick={() => setArenosa(true)}>Sí · sale de Arenosa o va para Arenosa</button>
                      <button type="button" className={arenosa === false ? "on" : ""}
                              aria-pressed={arenosa === false} onClick={() => setArenosa(false)}>No · es otra ruta</button>
                    </div>
                    <p className={"guia" + (arenosa === false ? " adicional" : "")} style={{ marginTop: 10 }}>
                      {arenosa === null
                        ? <>Hay que contestarlo para registrar: <b>solo las que salen de Arenosa o van para Arenosa cuentan</b> en el % de cumplimiento.</>
                        : arenosa
                          ? <>Cuenta en el <b>% de cumplimiento</b> del turno.</>
                          : <>Se registra igual, pero <b>no cuenta</b> en el % de cumplimiento.</>}
                    </p>
                  </div>
                )}

                {noMiden.length > 0 && (
                  <p className="guia adicional">
                    <b>{noMiden.map(nombreTipo).join(", ")}</b> se registra{noMiden.length === 1 ? "" : "n"} y
                    queda{noMiden.length === 1 ? "" : "n"} en los viajes del día, pero <b>no cuenta
                    {noMiden.length === 1 ? "" : "n"}</b> en el plan ni en el % de cumplimiento.
                  </p>
                )}

                <div>
                  <span className="rot-campo">Ruta</span>

                  {/* DOS BODEGAS, NO UNA "RUTA". Una ruta no es una cosa
                      que exista por sí sola: es de dónde sale y a dónde
                      llega, y las dos salen de la MISMA lista — la misma
                      bodega es origen unas veces y destino otras.

                      Hubo aquí un maestro de rutas, una lista de pares
                      aparte de la de bodegas. Era mantener dos listas
                      donde hay una, y el día que se desajustaran nadie
                      sabría cuál creer. Se botó antes de llegar a la
                      base. */}
                  <div className="ruta">
                    <Desplegable valor={origen} ariaLabel="De dónde sale"
                                 vacio="De dónde sale…" opciones={bodegas}
                                 extra="Otra bodega…"
                                 alEscoger={setOrigen}
                                 alExtra={() => setBodegaNueva({ lado: "o", texto: "" })} />

                    {/* VOLTEAR. La mitad de los viajes son el regreso del
                        anterior, y ahora que las dos puntas salen de la
                        misma lista voltearlas siempre tiene sentido. */}
                    <button type="button" className="voltear" aria-label="voltear la ruta"
                            disabled={!origen && !destino}
                            title="Voltear: la ruta de vuelta"
                            onClick={() => { const o = origen; setOrigen(destino); setDestino(o) }}>
                      <svg viewBox="0 0 24 24"><path d="M7 10h13M7 10l3-3M7 10l3 3" />
                        <path d="M17 14H4M17 14l-3-3M17 14l-3 3" /></svg>
                    </button>

                    <Desplegable valor={destino} ariaLabel="A dónde va"
                                 vacio="A dónde va…"
                                 opciones={bodegas.filter((b) => b.valor !== origen)}
                                 extra="Otra bodega…"
                                 alEscoger={setDestino}
                                 alExtra={() => setBodegaNueva({ lado: "d", texto: "" })} />
                  </div>

                  {bodegaNueva !== null && (
                    <div className="alta">
                      <input value={bodegaNueva.texto} autoFocus autoComplete="off"
                             aria-label="Bodega nueva"
                             placeholder={bodegaNueva.lado === "o"
                               ? "Nombre de la bodega de origen"
                               : "Nombre de la bodega de destino"}
                             onChange={(e) => setBodegaNueva({ ...bodegaNueva, texto: e.target.value })}
                             onKeyDown={(e) => {
                               if (e.key === "Enter") { e.preventDefault(); guardarBodegaNueva() }
                               if (e.key === "Escape") setBodegaNueva(null);
                             }} />
                      <button type="button" className="btn si chico"
                              disabled={!bodegaNueva.texto.trim() || mandando}
                              onClick={guardarBodegaNueva}>Agregar</button>
                      <button type="button" className="btn chico"
                              onClick={() => setBodegaNueva(null)}>Dejar así</button>
                    </div>
                  )}

                  {/* AQUÍ ESTABAN LAS RUTAS FRECUENTES —una fila de
                      atajos «FABRICA → BODEGA 38»— y las quitó Cristian.

                      La idea era ahorrar dos toques; lo que hacía era
                      poner SEIS botones grandes debajo de los dos
                      campos que acaban de contestar lo mismo. Y crecen:
                      cada par nuevo que alguien registra suma otro
                      botón, así que la fila se alarga sola hasta empujar
                      el resto del formulario fuera de la pantalla.

                      Los dos desplegables de arriba ya se teclean y
                      filtran; el atajo no ahorraba lo suficiente para
                      pagar el sitio que ocupaba.

                      Y SE FUE TAMBIÉN LA CONSULTA. `rutasFrecuentes()`
                      corría en cada carga de la pantalla para llenar
                      estos seis botones; dejarla pedida «por si acaso»
                      es trabajo que alguien paga en tiempo de carga sin
                      que nada lo use. La cuenta sale de los viajes ya
                      registrados, así que el día que se quiera —como
                      pista al lado del destino, por ejemplo— se vuelve
                      a pedir y ya. La función sigue en `datos.ts`. */}

                  {puntosVivos.length === 0 && (
                    <p className="guia" style={{ marginTop: 10 }}>
                      Todavía no hay bodegas. Agrégalas aquí mismo con <b>Otra bodega…</b>, o
                      en <b>Maestro → Bodegas</b>.
                    </p>
                  )}
                </div>
              </>
            )}

            {/* ---------- CUÁNTO LLEVA DE CADA TIPO ----------

                EL CONTADOR DE VIAJES SE FUE DEL VIAJE CON CARGA, y no es
                que se esconda: es que ya no existe. Un vehículo es UN
                viaje; lo que puede ser más de uno son los tipos que
                lleva encima, y eso ahora se escoge arriba. Dejar el
                contador al lado invitaría a poner 3 y registrar nueve
                planes con un solo camión.

                Los VACÍOS sí lo conservan: un vacío no es un vehículo
                con papel, es un número de viajes del turno, y meter los
                cinco de una es justo para lo que sirve. */}
            {modo === "vacio" ? (
              <div className="linea-campos">
                <div>
                  <span className="rot-campo">¿Cuántos viajes vacíos?</span>
                  <div className="conteo">
                    <span className="cel-step grande">
                      <button type="button" onClick={() => setViajesN(Math.max(1, viajesN - 1))}
                              aria-label="uno menos">−</button>
                      <input value={viajesN} inputMode="numeric" aria-label="cuántos viajes"
                             onChange={(e) =>
                               setViajesN(Math.max(1, Number(e.target.value.replace(/\D/g, "")) || 1))} />
                      <button type="button" onClick={() => setViajesN(viajesN + 1)}
                              aria-label="uno más">+</button>
                    </span>
                    <span className="nota-conteo">
                      No entran en el cumplido: cuestan igual y no mueven producto.
                    </span>
                  </div>
                </div>
              </div>
            ) : escogidos.length > 0 && (
              <div>
                <span className="rot-campo">
                  Cuánto lleva de cada tipo <em className="rot-suave">(opcional)</em>
                </span>
                <div className="por-tipo">
                  {escogidos.map((c, i) => (
                    <label key={c} className="pt-fila">
                      <span className="pt-nombre">
                        {nombreTipo(c)}
                        {/* CUÁL ES EL PRINCIPAL, DICHO. Es el que queda
                            en la columna del viaje y el que sale en la
                            lista de abajo; sin decirlo, el orden en que
                            se tocaron los chips sería una regla
                            invisible. */}
                        {i === 0 && escogidos.length > 1 && <i>principal</i>}
                      </span>
                      <input value={tipos_.get(c) ?? ""} inputMode="numeric"
                             placeholder="Canastas, estibas…"
                             aria-label={`Cuánto lleva de ${nombreTipo(c)}`}
                             onChange={(e) => ponCantidad(c, e.target.value)} />
                    </label>
                  ))}
                </div>
                <p className="guia" style={{ marginTop: 8 }}>
                  Este viaje avanza <b>{escogidos.length}</b> plan
                  {escogidos.length === 1 ? "" : "es"} del turno, uno por tipo. El vehículo
                  salió una vez; el plan se mide por tipo.
                </p>
              </div>
            )}

            {/* LA NOVEDAD VA PLEGADA: se usa en uno de cada veinte
                viajes, y un campo grande que casi nunca se llena empuja
                el botón fuera de la pantalla en el celular. */}
            <details className="extra">
              <summary>Agregar novedad</summary>
              <textarea value={nota} placeholder="Solo si pasó algo que haya que contar"
                        onChange={(e) => setNota(e.target.value)} />
            </details>
          </div>

          <div className="pie-reg">
            <button type="button" className="btn si" disabled={!puedeMandar || mandando}
                    onClick={mandar}>
              {mandando ? "Registrando…"
                : modo === "vacio" ? `Registrar ${viajesN} vacío${viajesN === 1 ? "" : "s"}`
                : !placa.trim() ? "Falta la placa"
                : escogidos.length === 0 ? (hayPlan ? "Escoge del plan" : "Falta el tipo")
                : !origen.trim() || !destino.trim() ? "Falta la ruta"
                /* El botón dice lo que va a pasar. "Registrar viaje" cuando
                   el viaje se sale del plan esconde justo lo que había que
                   avisar. Y con varios tipos dice CUÁNTOS, porque el total
                   del turno va a subir esa cifra y no uno. */
                : fueraDelPlan.length === 0
                  ? (escogidos.length === 1 ? "Registrar viaje" : `Registrar · ${escogidos.length} tipos`)
                : fueraDelPlan.length === escogidos.length
                  ? `Registrar ${escogidos.length === 1 ? "adicional" : `${escogidos.length} adicionales`}`
                : `Registrar (${fueraDelPlan.length} adicional${fueraDelPlan.length === 1 ? "" : "es"})`}
            </button>
            <span className="atajo">o pulsa <kbd>Ctrl</kbd> + <kbd>Enter</kbd></span>
          </div>
        </section>

        <aside>
          {/* EL PLAN DEL TURNO, EN CUADRITOS. Un cuadro por viaje
              planeado, encendido al registrarlo. "4 de 16" se entiende
              leyendo; doce cuadros apagados se entienden sin leer. */}
          <div className="plan-turno">
            <div className="corte" aria-hidden />
            <div className="rot">PLAN DEL TURNO {turno}</div>
            <div className="marca">
              {/* "1 de 0 viajes" no quiere decir nada. Sin plan, la cifra
                  que hay es cuántos van registrados y ya. */}
              <b>{hechos}</b>
              <span>{plan > 0 ? `de ${plan} viajes` : hechos === 1 ? "viaje, sin plan" : "viajes, sin plan"}</span>
            </div>
            {plan > 0 ? (
              <>
                <div className="huecos">
                  {Array.from({ length: Math.min(plan, 30) }, (_, i) => (
                    <i key={i} className={i < hechos ? "lleno" : undefined} />
                  ))}
                </div>
                <div className="pie-plan">Cada cuadro es un viaje del plan. Se prende al registrarlo.</div>
              </>
            ) : (
              <div className="pie-plan">
                Este turno no tiene plan publicado. Se puede registrar igual — va a salir como
                «sin planear» en Control.
              </div>
            )}
          </div>

          <div className="hoy">
            <div className="cab">
              <h3>Viajes de hoy</h3>
              <span className="cuantos">{viajes.filter((v) => v.vale).length} registrados</span>
            </div>
            {viajes.length === 0 ? (
              <div className="vacio-hoy">
                Todavía no hay viajes hoy.<br />El primero que registres aparece aquí.
              </div>
            ) : (
              viajes.slice(0, 12).map((v) => (
                <div className={"viaje" + (v.vale ? "" : " anulado")} key={v.id}>
                  <span className="hora">{hora(v.hora)}</span>
                  <span>
                    <span className="pl">{v.vacio ? `${v.viajes} vacíos` : v.placa}</span>
                    <span className="det">
                      {v.vacio
                        ? `Turno ${v.turno} · ${quien(nombres, v.registrado_por)}`
                        /* EL DOCUMENTO DE PRIMERO en este renglón: la
                           lista de al lado se mira para responder «¿ya
                           metí este papel?», y la respuesta es el
                           número, no la ruta. */
                        : `${v.documento ? v.documento + " · " : ""}${v.tipo_nombre}`
                          + ` · ${v.origen_nombre} → ${v.destino_nombre}`}
                    </span>
                  </span>
                  {!v.vale && <span className="eti mal">ANULADO</span>}
                </div>
              ))
            )}
          </div>
        </aside>
      </div>
    </>
  );
}


