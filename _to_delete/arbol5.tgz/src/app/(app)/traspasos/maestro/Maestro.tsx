"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useAvisos } from "@/components/Aviso";
import type { PlacaM, Punto, PuntoFaltante, TipoViaje } from "@/modulos/traspasos/datos";

/**
 * EL MAESTRO DE TRASPASOS.
 *
 * Tres listas: BODEGAS, TIPOS y PLACAS. Es todo lo que se puede escoger
 * al registrar un viaje — y por eso vive aquí y no en el código: el día
 * que abran una bodega o entre un vehículo nuevo, nadie debería esperar
 * un despliegue.
 *
 * NO HAY MAESTRO DE RUTAS, y llegó a haberlo. Una ruta no es una cosa
 * que exista por sí sola: es de dónde sale y a dónde llega, y las dos
 * puntas salen de esta misma lista de bodegas — la misma bodega es
 * origen unas veces y destino otras. Mantener además una lista de pares
 * era mantener dos listas donde hay una.
 *
 * BORRAR NO SIGNIFICA LO MISMO EN LAS CUATRO, y la diferencia no es una
 * preferencia sino el esquema:
 *
 *   BODEGAS Y TIPOS  traspasos_viajes los REFERENCIA por llave foránea
 *                    (origen, destino, tipo). Borrar uno usado lo
 *                    rechaza la base, así que la pantalla lo dice antes
 *                    en vez de dejar salir un "violates foreign key
 *                    constraint", que no le explica nada a nadie.
 *
 *   PLACAS           no hay ninguna llave foránea hacia ellas: la placa
 *                    se guarda como TEXTO dentro de cada viaje. Se
 *                    pueden borrar siempre; los viajes no se tocan, solo
 *                    dejan de ofrecerse al registrar.
 *
 * Y abajo, POSIBLES DUPLICADOS: el mismo sitio escrito de dos formas.
 * Mientras uno de los dos esté suelto no cuenta en ningún informe por
 * punto, así que unirlos no es cosmética.
 */

type Uso = {
  tipos: Record<string, number>;
  puntos: Record<string, number>;
  placas: Record<string, number>;
  rutas: Record<string, number>;
  ultima: Record<string, string>;
  falta: boolean;
};

/** Es una lista del maestro: puntos o tipos. Los dos se pintan igual. */
type Fila = {
  clave: string;
  nombre: string;
  sub: string | null;
  activo: boolean;
  viajes: number;
};

export function Maestro({ tipos, puntos, placas, faltantes, uso, puedeEditar }: {
  tipos: TipoViaje[];
  puntos: Punto[];
  placas: PlacaM[];
  faltantes: PuntoFaltante[];
  uso: Uso;
  puedeEditar: boolean;
}) {
  const router = useRouter();
  const supabase = createClient();
  const [avisar, avisos] = useAvisos();
  const [mandando, setMandando] = useState(false);

  const [nuevoPunto, setNuevoPunto] = useState("");
  const [nuevoTipo, setNuevoTipo] = useState("");
  const [nuevaPlaca, setNuevaPlaca] = useState("");

  /* SOLO QUEDAN LOS DUPLICADOS. La franja de "sitios escritos a mano"
     se fue, y no por gusto: existía porque Registrar dejaba escribir el
     sitio a mano. Ahora Registrar escoge del maestro, así que por ahí ya
     no entra nada nuevo — la franja solo podía mostrar restos viejos.

     Lo que SÍ sigue haciendo falta es unir esos restos con el punto al
     que pertenecen: mientras estén sueltos no cuentan en ningún informe
     por punto. Eso es la sección de abajo, y esa se queda. */
  const dobles = faltantes.filter((f) => f.parecido);

  /* ------------------------------------------------------------------
     AGREGAR UN PUNTO.

     Va por la función y no por un insert directo porque la función es
     la que adopta los viajes que ya venían nombrando ese sitio a mano.
     Si la función todavía no está —falta correr la migración— se cae
     al insert de antes en vez de dejar la pantalla muerta, y se dice
     qué archivo falta.
     ------------------------------------------------------------------ */
  async function agregarPunto(nombre: string, sub?: string | null) {
    const n = nombre.trim();
    if (!n) return;
    setMandando(true);
    const r = await supabase.rpc("traspaso_agregar_punto", {
      p_nombre: n, p_descripcion: sub ?? null,
    });
    setMandando(false);

    if (!r.error) {
      const adoptados = (r.data as { adoptados: number }[] | null)?.[0]?.adoptados ?? 0;
      setNuevoPunto("");
      avisar.bien(
        adoptados
          ? `${n} quedó en el maestro y se llevó ${adoptados} viaje${adoptados === 1 ? "" : "s"} que estaban sueltos.`
          : `${n} quedó en el maestro. Los viajes nuevos ya lo pueden escoger.`,
      );
      router.refresh();
      return;
    }

    if (!faltaLaFuncion(r.error.message)) { avisar.mal(r.error.message); return }

    const { error } = await supabase.from("traspasos_puntos")
      .insert({ clave: clave(n), nombre: n });
    if (error) { avisar.mal(error.message); return }
    setNuevoPunto("");
    avisar.bien(
      `${n} quedó en el maestro. Los viajes viejos que lo nombraban siguen sueltos: ` +
      `para que se los lleve hay que correr supabase/migraciones/2026-09-traspasos-maestro.sql.`,
    );
    router.refresh();
  }

  async function unir(texto: string, clavePunto: string, nombrePunto: string) {
    setMandando(true);
    const { data, error } = await supabase.rpc("traspaso_unir_punto",
      { p_texto: texto, p_clave: clavePunto });
    setMandando(false);
    if (error) {
      avisar.mal(faltaLaFuncion(error.message)
        ? "Para unir puntos falta correr supabase/migraciones/2026-09-traspasos-maestro.sql en Supabase."
        : error.message);
      return;
    }
    const n = (data as number) ?? 0;
    avisar.bien(`${n} viaje${n === 1 ? "" : "s"} que decían «${texto}» ahora cuentan en ${nombrePunto}.`);
    router.refresh();
  }

  async function agregarPlaca() {
    const n = nuevaPlaca.trim();
    if (!n) return;
    setMandando(true);
    const { data, error } = await supabase.rpc("traspaso_agregar_placa",
      { p_placa: n, p_nota: null });
    setMandando(false);
    if (error) {
      avisar.mal(faltaLaFuncion(error.message)
        ? "Falta correr supabase/migraciones/2026-09-traspasos-placas-rutas.sql en Supabase."
        : error.message);
      return;
    }
    setNuevaPlaca("");
    /* Se dice CÓMO quedó guardada. Normalizar en silencio es la manera
       más rápida de que alguien jure que escribió otra cosa. */
    avisar.bien(`${data} quedó en el maestro de placas.`);
    router.refresh();
  }

  async function agregarTipo() {
    const n = nuevoTipo.trim();
    if (!n) return;
    setMandando(true);
    const { error } = await supabase.from("traspasos_tipos")
      .insert({ clave: clave(n).toLowerCase(), nombre: n,
                orden: (tipos.at(-1)?.orden ?? 0) + 1 });
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    setNuevoTipo("");
    avisar.bien(`${n} quedó en la lista de tipos.`);
    router.refresh();
  }

  /* La columna llave no siempre se llama `clave`: en placas es `placa` y
     en rutas es `id`. Se pasa como parámetro en vez de darla por hecha. */
  async function cambiar(tabla: string, col: string, c: string,
                         campos: Record<string, unknown>) {
    setMandando(true);
    const { error } = await supabase.from(tabla).update(campos).eq(col, c);
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    router.refresh();
  }

  async function borrar(tabla: string, col: string, c: string, nombre: string) {
    setMandando(true);
    const { error } = await supabase.from(tabla).delete().eq(col, c);
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    avisar.bien(`${nombre} se borró del maestro.`);
    router.refresh();
  }

  async function ordenar(fn: string, claves: string[]) {
    const { error } = await supabase.rpc(fn, { p_claves: claves });
    if (error) {
      avisar.mal(faltaLaFuncion(error.message)
        ? "Para cambiar el orden falta correr supabase/migraciones/2026-09-traspasos-maestro.sql en Supabase."
        : error.message);
      router.refresh();
      return;
    }
    router.refresh();
  }

  const filasPuntos: Fila[] = puntos.map((p) => ({
    clave: p.clave, nombre: p.nombre,
    sub: p.descripcion ?? (p.externo ? "Fuera del centro" : "Dentro del centro"),
    activo: p.activo, viajes: uso.puntos[p.clave] ?? 0,
  }));

  const filasPlacas: Fila[] = placas.map((p) => ({
    clave: p.placa, nombre: p.placa, sub: p.nota,
    activo: p.activo, viajes: uso.placas[p.placa] ?? 0,
  }));

  const filasTipos: Fila[] = tipos.map((t) => ({
    clave: t.clave, nombre: t.nombre,
    sub: subDeTipo(uso.ultima["tipo:" + t.clave]),
    activo: t.activo, viajes: uso.tipos[t.clave] ?? 0,
  }));

  return (
    <>
      {avisos}

      {uso.falta && (
        <div className="aviso">
          Las cuentas de uso vienen de una vista que todavía no existe: hasta que corras{" "}
          <b>supabase/migraciones/2026-09-traspasos-maestro.sql</b> todo va a decir 0 viajes,
          así que aquí no se ofrece borrar nada.
        </div>
      )}

      {/* IZQUIERDA: dónde y con qué. DERECHA: qué se mueve.
          Las dos columnas se apilan por su cuenta — ver el CSS. */}
      <section className="maestro">
        <div className="col">
        {/* ---------------- BODEGAS ---------------- */}
        <div className="caja-m">
          <div className="cab-m">
            <h2>Bodegas <em>{puntos.length}</em></h2>
            <p>De dónde sale y a dónde llega un viaje. Una sola lista: la misma bodega es origen unas veces y destino otras.</p>
          </div>

          {puedeEditar && (
            <form className="agregar-m"
                  onSubmit={(e) => { e.preventDefault(); agregarPunto(nuevoPunto) }}>
              <input value={nuevoPunto} placeholder="Nombre de la bodega — Ag01, Planta, Patio…"
                     onChange={(e) => setNuevoPunto(e.target.value)} />
              <button type="submit" disabled={!nuevoPunto.trim() || mandando}>Agregar</button>
            </form>
          )}

          {puntos.length === 0 ? (
            <div className="vacio">
              <b>El maestro está vacío</b>
              Mientras tanto los sitios se escriben a mano en el registro y aparecen arriba
              para agregarlos de un toque.
            </div>
          ) : (
            <Lista filas={filasPuntos} puedeEditar={puedeEditar} mandando={mandando}
                   sinUso={uso.falta}
                   alOrdenar={(cs) => ordenar("traspaso_ordenar_puntos", cs)}
                   alPrender={(c, a) => cambiar("traspasos_puntos", "clave", c, { activo: a })}
                   alRenombrar={(c, nom, sub) =>
                     cambiar("traspasos_puntos", "clave", c, { nombre: nom, descripcion: sub })}
                   alBorrar={(c, n) => borrar("traspasos_puntos", "clave", c, n)} />
          )}
        </div>

        {/* ---------------- PLACAS ---------------- */}
        <div className="caja-m">
          <div className="cab-m">
            <h2>Placas <em>{placas.length}</em></h2>
            <p>
              Los vehículos que se pueden escoger al registrar. Se guardan sin espacios ni
              guiones y en mayúsculas, así «abc 123» y «ABC-123» son un solo vehículo.
            </p>
          </div>

          {puedeEditar && (
            <form className="agregar-m"
                  onSubmit={(e) => { e.preventDefault(); agregarPlaca() }}>
              <input value={nuevaPlaca} placeholder="Placa — ABC123"
                     autoComplete="off" spellCheck={false}
                     onChange={(e) => setNuevaPlaca(e.target.value)} />
              <button type="submit" disabled={!nuevaPlaca.trim() || mandando}>Agregar</button>
            </form>
          )}

          {placas.length === 0 ? (
            <div className="vacio">
              <b>Todavía no hay placas</b>
              Al correr la migración se siembran solas con las que ya se venían registrando.
            </div>
          ) : (
            <Lista filas={filasPlacas} puedeEditar={puedeEditar} mandando={mandando}
                   sinUso={uso.falta}
                   alOrdenar={(cs) => ordenar("traspaso_ordenar_placas", cs)}
                   alPrender={(c, a) => cambiar("traspasos_placas", "placa", c, { activo: a })}
                   borrarSiempre
                   alRenombrar={(c, _nom, sub) =>
                     cambiar("traspasos_placas", "placa", c, { nota: sub })}
                   alBorrar={(c, n) => borrar("traspasos_placas", "placa", c, n)} />
          )}
        </div>
        </div>

        <div className="col">
        {/* ---------------- TIPOS ---------------- */}
        <div className="caja-m">
          <div className="cab-m">
            <h2>Tipos de viaje <em>{tipos.length}</em></h2>
            <p>
              Qué se mueve. Un tipo apagado no se borra: las planeaciones viejas lo siguen
              nombrando, solo deja de poderse escoger.
            </p>
          </div>

          {puedeEditar && (
            <form className="agregar-m"
                  onSubmit={(e) => { e.preventDefault(); agregarTipo() }}>
              <input value={nuevoTipo} placeholder="Nombre del tipo"
                     onChange={(e) => setNuevoTipo(e.target.value)} />
              <button type="submit" disabled={!nuevoTipo.trim() || mandando}>Agregar</button>
            </form>
          )}

          <Lista filas={filasTipos} puedeEditar={puedeEditar} mandando={mandando}
                 sinUso={uso.falta} sinSub
                 alOrdenar={(cs) => ordenar("traspaso_ordenar_tipos", cs)}
                 bandera={{
                   rotulo: "Lleva vidrio en tolvas",
                   marca: "vidrio",
                   puesta: (c) => tipos.find((t) => t.clave === c)?.lleva_vidrio === true,
                   alCambiar: (c, v) =>
                     cambiar("traspasos_tipos", "clave", c, { lleva_vidrio: v }),
                 }}
                 alPrender={(c, a) => cambiar("traspasos_tipos", "clave", c, { activo: a })}
                 alRenombrar={(c, nom) => cambiar("traspasos_tipos", "clave", c, { nombre: nom })}
                 alBorrar={(c, n) => borrar("traspasos_tipos", "clave", c, n)} />
        </div>
        </div>
      </section>

      {/* ---------------- DUPLICADOS ---------------- */}
      {dobles.length > 0 && (
        <section className="duplicados">
          <h3>Posibles duplicados</h3>
          <p>
            Mismo sitio escrito de dos formas. Si se dejan así, el informe por punto parte el
            mismo lugar en dos y ninguno cuadra. Unir no borra nada: los viajes que decían la
            forma de la izquierda pasan a contar en la de la derecha.
          </p>
          {dobles.map((f) => (
            <div className="par-dup" key={f.texto}>
              <span className="tx">{f.texto}</span>
              <span className="cuantos">{f.veces} viaje{f.veces === 1 ? "" : "s"}</span>
              <span className="fl" aria-hidden>→</span>
              <span className="tx gana">{f.parecido_nombre}</span>
              <span className="cuantos">{f.parecido_viajes ?? 0} viajes</span>
              {puedeEditar && (
                <button type="button" className="unir" disabled={mandando}
                        onClick={() => unir(f.texto, f.parecido!, f.parecido_nombre!)}>
                  Unir en {f.parecido_nombre}
                </button>
              )}
            </div>
          ))}
        </section>
      )}
    </>
  );
}

/* =====================================================================
   LA LISTA
   ===================================================================== */

function Lista({ filas, puedeEditar, mandando, sinUso, sinSub, sinRenombrar, borrarSiempre,
                 bandera, alOrdenar, alPrender, alRenombrar, alBorrar }: {
  filas: Fila[];
  puedeEditar: boolean;
  mandando: boolean;
  sinUso: boolean;
  sinSub?: boolean;
  /** Una ruta no tiene nombre propio: es el par de puntos. Cambiarle el
   *  nombre no querría decir nada, así que esa opción no se ofrece. */
  sinRenombrar?: boolean;
  /** SE PUEDE BORRAR AUNQUE SE HAYA USADO. Vale para placas y rutas, y
   *  no por relajar la regla: es que la regla no aplica. Ver abajo. */
  borrarSiempre?: boolean;
  /* UNA CASILLA MÁS DE LA FILA, la que solo tiene sentido en una de las
     listas. Hoy es «lleva vidrio en tolvas», de los tipos. Va aquí
     genérica y no dentro de `Fila` porque las otras tres listas no
     tienen ninguna, y una propiedad que casi siempre sobra se vuelve
     una que nadie sabe si hay que llenar. */
  bandera?: {
    rotulo: string;
    /** Lo que se pinta al lado del nombre cuando está puesta. */
    marca: string;
    puesta: (clave: string) => boolean;
    alCambiar: (clave: string, valor: boolean) => void;
  };
  alOrdenar: (claves: string[]) => void;
  alPrender: (clave: string, activo: boolean) => void;
  alRenombrar: (clave: string, nombre: string, sub: string | null) => void;
  alBorrar: (clave: string, nombre: string) => void;
}) {
  /* El orden que se está viendo. Sale de lo que llegó del servidor y
     solo se aparta de él mientras alguien arrastra. */
  const [orden, setOrden] = useState<string[]>(() => filas.map((f) => f.clave));
  const [moviendo, setMoviendo] = useState<string | null>(null);
  const caja = useRef<HTMLDivElement>(null);

  const llaves = filas.map((f) => f.clave).join("|");
  useEffect(() => { setOrden(filas.map((f) => f.clave)) },
            // eslint-disable-next-line react-hooks/exhaustive-deps
            [llaves]);

  const porClave = new Map(filas.map((f) => [f.clave, f]));
  const vistas = orden.map((c) => porClave.get(c)).filter(Boolean) as Fila[];

  /* ------------------------------------------------------------------
     ARRASTRAR CON EL DEDO O CON EL RATÓN.

     Con eventos de puntero y NO con la API de arrastrar del navegador:
     esa no existe en un celular, y el maestro se ordena tanto desde el
     escritorio como desde la tableta del muelle. La posición se calcula
     con la mitad de cada renglón, que es lo que hace que el salto pase
     cuando el dedo pasa por la mitad y no cuando toca el borde.
     ------------------------------------------------------------------ */
  function tomar(e: React.PointerEvent, clave: string) {
    if (!puedeEditar) return;
    (e.target as Element).setPointerCapture?.(e.pointerId);
    setMoviendo(clave);
  }

  function mover(e: React.PointerEvent) {
    if (!moviendo || !caja.current) return;
    const filasDom = Array.from(caja.current.querySelectorAll<HTMLElement>(".item"));
    const y = e.clientY;
    let destino = filasDom.length - 1;
    for (let i = 0; i < filasDom.length; i++) {
      const r = filasDom[i].getBoundingClientRect();
      if (y < r.top + r.height / 2) { destino = i; break }
    }
    const desde = orden.indexOf(moviendo);
    if (desde < 0 || desde === destino) return;
    const siguiente = orden.slice();
    siguiente.splice(destino, 0, siguiente.splice(desde, 1)[0]);
    setOrden(siguiente);
  }

  function soltar() {
    if (!moviendo) return;
    setMoviendo(null);
    /* Solo se guarda si de verdad cambió: un toque en el asa sin
       arrastrar no tiene por qué escribir en la base. */
    if (orden.join("|") !== llaves) alOrdenar(orden);
  }

  return (
    <div ref={caja} onPointerMove={mover} onPointerUp={soltar} onPointerCancel={soltar}>
      {vistas.map((f) => (
        <Renglon key={f.clave} f={f} sinSub={sinSub} sinUso={sinUso}
                 sinRenombrar={sinRenombrar} borrarSiempre={borrarSiempre}
                 puedeEditar={puedeEditar} mandando={mandando}
                 moviendo={moviendo === f.clave}
                 alTomar={(e) => tomar(e, f.clave)}
                 bandera={bandera}
                 alPrender={alPrender} alRenombrar={alRenombrar} alBorrar={alBorrar} />
      ))}
    </div>
  );
}

function Renglon({ f, sinSub, sinRenombrar, borrarSiempre, sinUso, puedeEditar, mandando,
                   moviendo, bandera, alTomar, alPrender, alRenombrar, alBorrar }: {
  f: Fila;
  sinSub?: boolean;
  sinRenombrar?: boolean;
  borrarSiempre?: boolean;
  sinUso: boolean;
  puedeEditar: boolean;
  mandando: boolean;
  moviendo: boolean;
  bandera?: {
    rotulo: string; marca: string;
    puesta: (clave: string) => boolean;
    alCambiar: (clave: string, valor: boolean) => void;
  };
  alTomar: (e: React.PointerEvent) => void;
  alPrender: (clave: string, activo: boolean) => void;
  alRenombrar: (clave: string, nombre: string, sub: string | null) => void;
  alBorrar: (clave: string, nombre: string) => void;
}) {
  const [menu, setMenu] = useState(false);
  /* HACIA DÓNDE SE ABRE, y se mide contra LA TARJETA, no contra la
     pantalla. Abierto hacia abajo en el último renglón, el menú se
     montaba encima de la tarjeta de al lado: no se cortaba, pero se veía
     como si fuera parte de la otra. Así que si no cabe abajo y sí cabe
     arriba, se abre hacia arriba y queda dentro de su propia tarjeta.
     Solo cuando no cabe de ningún lado —una tarjeta de dos renglones—
     se decide por la pantalla, que es lo único que queda.
     null = todavía sin medir: se pinta invisible un cuadro. */
  const [arriba, setArriba] = useState<boolean | null>(null);
  const [editando, setEditando] = useState(false);
  const [nom, setNom] = useState(f.nombre);
  const [sub, setSub] = useState(f.sub ?? "");
  const cajaMenu = useRef<HTMLDivElement>(null);
  const disparo = useRef<HTMLButtonElement>(null);
  const hoja = useRef<HTMLDivElement>(null);

  /* SE MIDE EL MENÚ DE VERDAD, no se estima. Un menú con la nota de
     "los 44 viajes no se pierden" mide el doble que uno de dos
     opciones; calcularlo a ojo era equivocarse en la mitad de las
     filas. Se pinta invisible, se mide, se coloca — todo antes de que
     el ojo alcance a ver nada. */
  useEffect(() => {
    if (!menu) { setArriba(null); return }
    const m = hoja.current, d = disparo.current;
    if (!m || !d) return;
    const alto = m.offsetHeight;
    const r = d.getBoundingClientRect();
    const caja = (d.closest(".caja-m") ?? d.closest(".tp"))!.getBoundingClientRect();
    const abajo = caja.bottom - r.bottom - 4;
    const encima = r.top - caja.top - 4;
    if (alto <= abajo) setArriba(false);
    else if (alto <= encima) setArriba(true);
    else {
      const vAbajo = window.innerHeight - r.bottom;
      setArriba(alto > vAbajo && r.top > vAbajo);
    }
  }, [menu]);

  /* Un menú abierto se cierra al tocar cualquier otra parte. Sin esto
     quedan tres menús abiertos a la vez y el de abajo tapa al de
     arriba.
     SE PREGUNTA POR EL NODO Y NO SE CORTA EL EVENTO. React no cuelga
     sus escuchas de document sino de la raíz de la app, así que un
     stopPropagation de React no detiene esta escucha: el menú se
     cerraría antes de que llegara el clic y ninguna opción de adentro
     llegaría a funcionar nunca. */
  useEffect(() => {
    if (!menu) return;
    const fuera = (e: PointerEvent) => {
      if (!cajaMenu.current?.contains(e.target as Node)) setMenu(false);
    };
    document.addEventListener("pointerdown", fuera);
    return () => document.removeEventListener("pointerdown", fuera);
  }, [menu]);

  /* CUÁNDO SE PUEDE BORRAR, y por qué son dos reglas distintas.

     PUNTOS Y TIPOS: solo si nunca se usaron. La tabla de viajes los
     REFERENCIA por llave foránea —traspasos_viajes.origen, .destino y
     .tipo—, así que borrar uno usado lo rechazaría la base. Se dice
     antes en vez de dejar salir un "violates foreign key constraint".

     PLACAS Y RUTAS: siempre. No hay ninguna llave foránea hacia ellas:
     la placa se guarda como texto dentro de cada viaje y la ruta sale
     del origen y el destino de ese viaje. Borrarlas del maestro no
     toca un solo viaje —siguen con su placa y su ruta escritas—, solo
     dejan de ofrecerse al registrar. Copiar aquí la regla de puntos y
     tipos era prohibir algo que la base permite sin riesgo. */
  const sePuedeBorrar = puedeEditar && (borrarSiempre || (!sinUso && f.viajes === 0));

  if (editando) {
    return (
      <form className="agregar-m"
            onSubmit={(e) => {
              e.preventDefault();
              if (!nom.trim()) return;
              alRenombrar(f.clave, nom.trim(), sub.trim() || null);
              setEditando(false);
            }}>
        <input value={nom} autoFocus aria-label="Nombre"
               onChange={(e) => setNom(e.target.value)} />
        {!sinSub && (
          <input value={sub} placeholder="Subtítulo — Planta, Zona interna…"
                 aria-label="Subtítulo" onChange={(e) => setSub(e.target.value)} />
        )}
        <button type="submit" disabled={!nom.trim() || mandando}>Guardar</button>
        <button type="button" className="btn" onClick={() => {
          setNom(f.nombre); setSub(f.sub ?? ""); setEditando(false);
        }}>Dejar así</button>
      </form>
    );
  }

  return (
    <div className={"item" + (f.activo ? "" : " apagado") + (moviendo ? " arrastrando" : "")}>
      {puedeEditar ? (
        <button type="button" className="asa" onPointerDown={alTomar}
                aria-label={`Mover ${f.nombre}`} title="Arrastrar para cambiar el orden">
          <svg viewBox="0 0 24 24" aria-hidden>
            <path d="M9 6h.01M9 12h.01M9 18h.01M15 6h.01M15 12h.01M15 18h.01" />
          </svg>
        </button>
      ) : <span className="asa" />}

      <div className="nom">
        <b>{f.nombre}</b>
        {/* LA MARCA SE VE SIN ABRIR NADA. Una bandera que solo se
            asoma dentro de un menú de tres puntos es una bandera que
            nadie sabe que existe — y esta decide si al registrar sale
            el bloque del vidrio. */}
        {bandera?.puesta(f.clave) && <em className="bandera-m">{bandera.marca}</em>}
        {!sinSub || f.sub ? <span>{f.sub}</span> : null}
      </div>

      <span className="uso">
        {sinUso ? "—" : `${f.viajes.toLocaleString("es-CO")} viaje${f.viajes === 1 ? "" : "s"}`}
      </span>

      <label className="sw" title={f.activo ? "Se puede escoger" : "Ya no se puede escoger"}>
        <input type="checkbox" checked={f.activo} disabled={!puedeEditar || mandando}
               aria-label={`${f.nombre}: se puede escoger`}
               onChange={(e) => alPrender(f.clave, e.target.checked)} />
        <i />
      </label>

      <div className="mas" ref={cajaMenu}>
        <button type="button" ref={disparo} aria-label={`Opciones de ${f.nombre}`}
                aria-expanded={menu} onClick={() => setMenu((v) => !v)}>⋯</button>
        {menu && (
          <div ref={hoja}
               className={"menu" + (arriba === null ? " midiendo" : arriba ? " arriba" : "")}>
            {!sinRenombrar && (
              <button type="button" disabled={!puedeEditar}
                      onClick={() => { setMenu(false); setEditando(true) }}>
                {sinSub ? "Cambiar el nombre" : "Cambiar nombre y subtítulo"}
              </button>
            )}
            <button type="button" disabled={!puedeEditar || mandando}
                    onClick={() => { setMenu(false); alPrender(f.clave, !f.activo) }}>
              {f.activo ? "Apagar" : "Prender"}
            </button>
            {bandera && (
              <button type="button" disabled={!puedeEditar || mandando}
                      onClick={() => { setMenu(false);
                                       bandera.alCambiar(f.clave, !bandera.puesta(f.clave)) }}>
                {bandera.puesta(f.clave) ? `Quitar: ${bandera.rotulo}` : bandera.rotulo}
              </button>
            )}
            {sePuedeBorrar ? (
              <>
                <button type="button" className="mal" disabled={mandando}
                        onClick={() => { setMenu(false); alBorrar(f.clave, f.nombre) }}>
                  Borrar
                </button>
                {/* SE DICE QUÉ PASA CON LOS VIAJES. "Borrar" al lado de
                    "142 viajes" da a entender que se van con ella. */}
                {borrarSiempre && f.viajes > 0 && (
                  <div className="nota">
                    Los {f.viajes} viaje{f.viajes === 1 ? "" : "s"} que la nombran no se
                    pierden: queda escrita en cada uno. Solo deja de poderse escoger.
                  </div>
                )}
              </>
            ) : (
              <div className="nota">
                {sinUso
                  ? "Para saber si se puede borrar falta correr la migración del maestro."
                  : `No se puede borrar: ya lo nombran ${f.viajes} viaje${f.viajes === 1 ? "" : "s"}. Apágalo y deja de poderse escoger.`}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* =====================================================================
   AYUDAS
   ===================================================================== */

/** La clave a partir del nombre: sin acentos, sin espacios, en
 *  mayúsculas. Se genera y no se pide, porque nadie debería tener que
 *  inventarse un código para agregar "Patio de vacíos". Es la misma
 *  regla que traspaso_norm() en la base. */
function clave(nombre: string) {
  return nombre.normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 40);
}

function faltaLaFuncion(msg: string | undefined) {
  const t = (msg ?? "").toLowerCase();
  return t.includes("does not exist") || t.includes("schema cache")
      || t.includes("could not find the function");
}

/** El subtítulo de un tipo: cuándo se usó por última vez. Es lo que
 *  dice si un tipo sigue vivo sin tener que abrir un informe. */
function subDeTipo(ultima: string | undefined) {
  if (!ultima) return "sin uso";
  const dias = Math.floor((Date.now() - new Date(ultima + "T12:00:00").getTime()) / 86_400_000);
  if (dias <= 31) return "usado este mes";
  if (dias <= 93) return "usado hace unos meses";
  return "sin uso desde hace más de tres meses";
}
