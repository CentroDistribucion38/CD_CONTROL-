import { RUTA_FIRMA } from "@/modulos/roturas/firmas";
import { misPermisos } from "@/lib/permisos";
import { nombresTodos } from "@/modulos/sider/datos";
import { porRevisar, roturas as leerRoturas } from "@/modulos/roturas/datos";
import "../../roturas.css";
import { SinTablas } from "../../comunes";
import { VistoBueno } from "./VistoBueno";

export const dynamic = "force-dynamic";

export default async function VistoBuenoPage() {
  const [permisos, datos, todas, nombres] = await Promise.all([
    misPermisos(), porRevisar(), leerRoturas(1000), nombresTodos(),
  ]);

  if (datos.falta) return <div className="rt"><SinTablas /></div>;

  /* Quien tiene EDITAR en Visto bueno (o administra), no un rol con
     cierto nombre. Mismo criterio que rotura_puede('visto_bueno') en la base. Las dos
     capas dicen lo mismo, pero la que protege es la de abajo: a una
     pantalla escondida se llega igual escribiendo la URL. */
  const puedeDecidir = permisos.puedeEditar(RUTA_FIRMA.visto_bueno);

  /* El mismo montón en tres momentos. Tres cifras en fila con flechas
     se leen como un recorrido; tres cajas iguales se leen como tres
     medidas distintas, que es otra cosa. */
  const cuentan = todas.roturas.filter((r) => r.estado === "cuenta").length;
  const noCuentan = todas.roturas.filter((r) => r.estado === "no_cuenta").length;
  const enPleito = todas.roturas.filter((r) => r.etapa === "desacuerdo").length;

  return (
    <div className="rt">
      <section className="cabeza">
        <div>
          <p className="ojo">ROTURAS · VISTO BUENO DEL OPERADOR LOGÍSTICO</p>
          <h1>¿Estás de acuerdo?</h1>
          <p className="sub">
            Lo que el turno registró, esperando tu respuesta. Lo que aceptes <b>pasa a cobro
            de una</b> y no le llega a ABI: queda en la data del mes. Lo que objetes va a ABI
            con tu motivo y tu evidencia, y ahí ABI tiene la última palabra.
          </p>
        </div>
      </section>

      {/* EL `kpi` DE LA CABECERA SE FUE: decía «esperando tu respuesta:
          N» dos dedos por encima de la fila de cifras de la bandeja,
          que dice exactamente eso. Dos dibujos del mismo número son dos
          sitios donde puede quedar uno viejo. Las unidades en juego y
          la más vieja no se perdieron: viven en la cabecera de la
          bandeja y en cada fila, que es donde se usan. */}

      {!puedeDecidir && (
        <div className="aviso">
          Estás viendo la bandeja, pero contestar es de quien tenga <b>Editar</b> en esta
          pantalla — el operador logístico. Los botones aparecen cuando tengas ese permiso.
        </div>
      )}

      {datos.vieja && (
        <div className="aviso rojo">
          <b>Falta correr el SQL de la cadena nueva.</b> Mientras tanto esta bandeja mezcla lo
          que espera tu respuesta con lo que ya objetaste. Se arregla corriendo
          <b> supabase/migraciones/2026-09-roturas-visto-bueno-easy.sql</b>.
        </div>
      )}

      <VistoBueno roturas={datos.roturas} nombres={nombres} puedeDecidir={puedeDecidir}
                  cifras={{ aCobro: cuentan, enDesacuerdo: enPleito, noSeCobran: noCuentan }} />
    </div>
  );
}
