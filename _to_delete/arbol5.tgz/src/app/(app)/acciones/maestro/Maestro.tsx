"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useAvisos } from "@/components/Aviso";
import { useConfirmar } from "@/components/Confirmar";
import { usePedirTexto } from "@/components/PedirTexto";
import type { Area, Motivo, Zona } from "@/modulos/acciones/datos";

/**
 * MAESTRO — las zonas, los motivos y las áreas.
 *
 * Son DATOS, no código: el día que abran el pasillo 5 nadie debería tener
 * que esperar un despliegue. Por eso se crean, se editan, se desactivan y
 * se borran aquí.
 *
 * BORRAR Y DESACTIVAR NO SON LO MISMO, y la diferencia es la que evita
 * perder el histórico:
 *
 *   DESACTIVAR  deja de ofrecerse al reportar, pero las acciones viejas
 *               siguen mostrando su zona y siguen contando para la
 *               reincidencia. Es lo que se hace el 99% de las veces.
 *   BORRAR      solo se puede si NADIE la ha usado nunca. Es para el
 *               error de dedo: creaste "AG01-PAS-O5" con O de oso y
 *               quieres que desaparezca sin dejar rastro.
 *
 * Si algo ya tiene acciones, el botón de borrar no aparece y en su lugar
 * se dice cuántas tiene. La base lo rechazaría de todas formas por la
 * llave foránea, pero un "violates foreign key constraint" no le explica
 * nada a nadie; decirlo antes sí.
 *
 * LA CLAVE NO SE EDITA. En las zonas es el código pegado en la pared que
 * lee la cámara: cambiarlo aquí dejaría el QR apuntando a algo que ya no
 * existe. En los motivos es con lo que se agrupa la reincidencia: al
 * cambiarla, las tres apariciones viejas dejarían de ser "lo mismo". Se
 * edita el NOMBRE, que es lo que la gente lee; la clave se queda quieta.
 */

type Hoja = "zonas" | "motivos" | "areas" | "equipos";

/** Una clave legible a partir del nombre: "Pasillo 5" → "pasillo_5". */
function aClave(s: string) {
  return s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 40);
}

export function Maestro({ zonas, motivos, areas, equipos, uso, puedeEditar }: {
  zonas: Zona[];
  motivos: Motivo[];
  areas: Area[];
  /** Los OL que responden por una acción: Easy, Summar. */
  equipos: { clave: string; nombre: string; orden: number | null; activo: boolean }[];
  uso: {
    zonas: Record<string, number>; motivos: Record<string, number>;
    equipos: Record<string, number>;
  };
  puedeEditar: boolean;
}) {
  const router = useRouter();
  const supabase = createClient();
  const [avisar, avisos] = useAvisos();
  const [pedir, dialogo] = useConfirmar();
  const [pedirTexto, cuadro] = usePedirTexto();

  const [hoja, setHoja] = useState<Hoja>("zonas");
  const [nueva, setNueva] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [mandando, setMandando] = useState(false);
  const [escogidas, setEscogidas] = useState<Set<string>>(new Set());

  /* Un solo formulario para las tres hojas: los campos que no aplican no
     se pintan. Tres formularios separados serían tres sitios donde
     arreglar el mismo detalle. */
  const vacio = { clave: "", nombre: "", proceso: "", area: areas[0]?.clave ?? "", critico: false };
  const [f, setF] = useState(vacio);

  const tabla = hoja === "zonas" ? "acciones_zonas"
              : hoja === "motivos" ? "acciones_motivos"
              : hoja === "equipos" ? "acciones_equipos" : "acciones_areas";
  const llave = hoja === "zonas" ? "codigo" : "clave";

  function abrirNueva() {
    setF(vacio); setNueva(true); setEditando(null);
  }

  function abrirEditar(id: string) {
    setNueva(false);
    setEditando(editando === id ? null : id);
    if (hoja === "zonas") {
      const z = zonas.find((x) => x.codigo === id)!;
      setF({ clave: z.codigo, nombre: z.nombre, proceso: z.proceso ?? "", area: z.area, critico: false });
    } else if (hoja === "motivos") {
      const m = motivos.find((x) => x.clave === id)!;
      setF({ clave: m.clave, nombre: m.nombre, proceso: "", area: m.area ?? "", critico: m.critico });
    } else if (hoja === "equipos") {
      const e = equipos.find((x) => x.clave === id)!;
      setF({ clave: e.clave, nombre: e.nombre, proceso: "", area: "", critico: false });
    } else {
      const a = areas.find((x) => x.clave === id)!;
      setF({ clave: a.clave, nombre: a.nombre, proceso: "", area: "", critico: false });
    }
  }

  async function crear() {
    setMandando(true);
    const clave = hoja === "zonas"
      ? f.clave.trim().toUpperCase()
      : (f.clave.trim() || aClave(f.nombre));

    /* El tipo de la fila cambia con la hoja y PostgREST espera una forma
       concreta por tabla. Se arma como Record y se manda: tres inserts
       separados serían tres veces el mismo manejo de error. */
    const fila: Record<string, unknown> =
      hoja === "zonas"
        ? { codigo: clave, nombre: f.nombre.trim(), proceso: f.proceso.trim() || null, area: f.area }
        : hoja === "motivos"
          ? { clave, nombre: f.nombre.trim(), area: f.area || null, critico: f.critico }
          : { clave, nombre: f.nombre.trim() };

    const { error } = await supabase.from(tabla).insert(fila);
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    avisar.bien(`${f.nombre.trim()} quedó agregado.`);
    setNueva(false); setF(vacio); router.refresh();
  }

  async function guardar(id: string) {
    setMandando(true);
    const cambio: Record<string, unknown> =
      hoja === "zonas"
        ? { nombre: f.nombre.trim(), proceso: f.proceso.trim() || null, area: f.area }
        : hoja === "motivos"
          ? { nombre: f.nombre.trim(), area: f.area || null, critico: f.critico }
          : { nombre: f.nombre.trim() };

    const { error } = await supabase.from(tabla).update(cambio).eq(llave, id);
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    avisar.bien("Cambio guardado.");
    setEditando(null); router.refresh();
  }

  /* ---------- ESCOGER VARIAS Y ELIMINARLAS ----------
     «Que aquí yo pueda seleccionar varios y eliminar.»

     SOLO LAS QUE NADIE HA USADO. Es la misma regla que ya tenía el
     botón de una sola fila, y aquí importa MÁS: con las casillas es
     fácil marcar seis de un barrido, y si una de esas seis tiene
     acciones colgando, borrarla se llevaría el histórico que cuenta la
     reincidencia. Las que no se pueden ni siquiera ofrecen casilla. */
  async function borrarEscogidas() {
    const van = filas.filter((x) => escogidas.has(x.id));
    if (van.length === 0) return;
    const m = await pedirTexto({
      titulo: van.length === 1 ? `¿Eliminar ${van[0].nombre}?` : `¿Eliminar ${van.length}?`,
      dice: (
        <>
          {van.length === 1 ? <>Se va <b>{van[0].nombre}</b>.</>
            : <>Se van <b>{van.length}</b>: {van.slice(0, 4).map((x) => x.nombre).join(", ")}
               {van.length > 4 ? ` y ${van.length - 4} más` : ""}.</>}
          {" "}Ninguna se ha usado todavía, así que no se pierde histórico — pero{" "}
          <b>no hay deshacer</b>. Si lo que quieres es que dejen de ofrecerse al reportar,{" "}
          <b>desactívalas</b>: eso las quita de la lista y deja el histórico intacto.
        </>
      ),
      rotulo: "Por qué se eliminan",
      marcador: "Queda en el historial de administración",
      confirmar: `Eliminar ${van.length}`, peligro: true, minimo: 4, largo: true,
      debesEscribir: `ELIMINAR ${van.length}`,
    });
    if (m === null) return;

    setMandando(true);
    /* UNA SOLA LLAMADA CON TODAS LAS CLAVES. Una por fila serían seis
       formas de quedar a medias: se borran cuatro, se cae la red, y el
       maestro queda en un estado que nadie escogió. */
    const { error } = await supabase.from(tabla).delete().in(llave, van.map((x) => x.id));
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    avisar.bien(`Se eliminaron ${van.length}.`);
    setEscogidas(new Set());
    router.refresh();
  }

  async function alternar(id: string, activo: boolean) {
    const { error } = await supabase.from(tabla).update({ activo: !activo }).eq(llave, id);
    if (error) { avisar.mal(error.message); return }
    avisar.bien(activo ? "Desactivado. Deja de ofrecerse al reportar; el histórico se queda."
                       : "Activado. Ya se puede escoger al reportar.");
    router.refresh();
  }

  async function borrar(id: string, nombre: string) {
    /* Se pregunta con el diálogo de la aplicación y no con el cuadro gris
       del navegador, que sale con el dominio encima y parece que la app
       se rompió justo cuando alguien la está enseñando. */
    const si = await pedir({
      titulo: `¿Eliminar ${nombre}?`,
      dice: "Nadie lo ha usado todavía, así que no se pierde histórico — pero no hay deshacer. " +
            "Si algún día se usó, lo correcto es desactivarlo, no borrarlo.",
      confirmar: "Sí, eliminar",
      peligro: true,
    });
    if (!si) return;

    setMandando(true);
    const { error } = await supabase.from(tabla).delete().eq(llave, id);
    setMandando(false);
    if (error) { avisar.mal(error.message); return }
    avisar.bien(`${nombre} se eliminó.`);
    router.refresh();
  }

  const nombreArea = (c: string | null) => areas.find((a) => a.clave === c)?.nombre ?? c ?? "—";
  const usos = (id: string) =>
    hoja === "zonas" ? (uso.zonas[id] ?? 0)
    : hoja === "motivos" ? (uso.motivos[id] ?? 0)
    : hoja === "equipos" ? (uso.equipos[id] ?? 0)
    : 0;

  /* Las áreas no se cuentan por acción sino por lo que cuelga de ellas:
     una zona o un motivo apuntando a un área también impide borrarla. */
  const usosArea = (clave: string) =>
    zonas.filter((z) => z.area === clave).length + motivos.filter((m) => m.area === clave).length;

  const filas: { id: string; nombre: string; sub: string; activo: boolean; critico?: boolean }[] =
    hoja === "zonas"
      ? zonas.map((z) => ({
          id: z.codigo, nombre: z.nombre + (z.proceso ? ` · ${z.proceso}` : ""),
          sub: nombreArea(z.area), activo: z.activo,
        }))
      : hoja === "motivos"
        ? motivos.map((m) => ({
            id: m.clave, nombre: m.nombre, sub: nombreArea(m.area),
            activo: m.activo, critico: m.critico,
          }))
        : hoja === "equipos"
          ? equipos.map((e) => ({
              id: e.clave, nombre: e.nombre,
              sub: `${uso.equipos[e.clave] ?? 0} acciones asignadas`,
              activo: e.activo,
            }))
          : areas.map((a) => ({
              id: a.clave, nombre: a.nombre,
              sub: `${zonas.filter((z) => z.area === a.clave).length} zonas · ` +
                   `${motivos.filter((m) => m.area === a.clave).length} motivos`,
              activo: a.activo,
            }));

  /* LAS QUE SE PUEDEN ELIMINAR: las que nadie ha usado. Se calcula una
     vez y de ahí salen la casilla de cada fila y la de «escoger
     todas» — contarlo en dos sitios es cómo un día «las 6» marca 5. */
  const borrables = filas.filter((x) => (hoja === "areas" ? usosArea(x.id) : usos(x.id)) === 0);
  const todasPuestas = borrables.length > 0
    && borrables.every((x) => escogidas.has(x.id));

  const puedeGuardar = f.nombre.trim().length >= 2 &&
    (hoja !== "zonas" || f.clave.trim().length >= 4);

  return (
    <>
      {avisos}
      {dialogo}
      {cuadro}

      <div className="filtros">
        {(["zonas", "motivos", "areas"] as Hoja[]).map((h) => (
          <button key={h} type="button" className={"btn" + (hoja === h ? " si" : "")}
                  onClick={() => {
                    /* LA SELECCIÓN SE LIMPIA AL CAMBIAR DE HOJA. Sin
                       esto, marcar tres zonas, pasarse a Motivos y dar
                       Eliminar borraría cosas que ya no están en
                       pantalla — y eso no se ve hasta después. */
                    setHoja(h); setNueva(false); setEditando(null);
                    setEscogidas(new Set());
                  }}>
            {h === "zonas" ? `Zonas (${zonas.length})`
             : h === "motivos" ? `Motivos (${motivos.length})`
             : `Áreas (${areas.length})`}
          </button>
        ))}
        {puedeEditar && (
          <button type="button" className="btn mas-chico" onClick={() => (nueva ? setNueva(false) : abrirNueva())}>
            {nueva ? "Cancelar" : `+  Agregar ${hoja === "zonas" ? "zona" : hoja === "motivos" ? "motivo" : "área"}`}
          </button>
        )}
      </div>

      <section className="caja">
        <div className="cab">
          <div>
            <h2>{hoja === "zonas" ? "Las zonas de la bodega"
               : hoja === "motivos" ? "Los motivos" : "Las áreas"}</h2>
            <p>{TEXTO[hoja]}</p>
          </div>
        </div>

        {nueva && (
          <div className="panel" style={{ margin: 12 }}>
            <Campos hoja={hoja} f={f} setF={setF} areas={areas} nuevo />
            <div className="acciones-panel">
              <button type="button" className="btn si" disabled={mandando || !puedeGuardar}
                      onClick={crear}>
                {mandando ? "Guardando…" : "Agregar"}
              </button>
              <button type="button" className="btn plano" onClick={() => setNueva(false)}>Cancelar</button>
            </div>
          </div>
        )}

        {/* ESCOGER VARIAS — solo las que se pueden eliminar.
            Ofrecer casilla en una zona con acciones colgando sería
            ofrecer algo que después la pantalla niega, y una regla
            correcta contada como un regaño es peor que no tenerla. */}
        {puedeEditar && borrables.length > 0 && (
          <div className="ac-m-sel">
            <label className="ac-m-todas">
              <input type="checkbox" checked={todasPuestas}
                     aria-label={`Escoger las ${borrables.length} que se pueden eliminar`}
                     onChange={() => setEscogidas(todasPuestas
                       ? new Set() : new Set(borrables.map((x) => x.id)))} />
              <span>
                {todasPuestas
                  ? `Las ${borrables.length} sin usar están escogidas`
                  : `Escoger las ${borrables.length} que nunca se han usado`}
              </span>
            </label>
            {escogidas.size > 0 && (
              <div className="ac-m-acc">
                <span className="ac-m-cuenta"><b>{escogidas.size}</b> escogida
                  {escogidas.size === 1 ? "" : "s"}</span>
                <button type="button" className="btn plano" disabled={mandando}
                        onClick={() => setEscogidas(new Set())}>Quitar la selección</button>
                <button type="button" className="btn mal" disabled={mandando}
                        onClick={borrarEscogidas}>
                  {mandando ? "Eliminando…" : `Eliminar ${escogidas.size}`}
                </button>
              </div>
            )}
          </div>
        )}

        <div className="rueda">
          {filas.length === 0 && (
            <div className="vacio">
              <b>Todavía no hay nada</b>
              El botón de arriba agrega {hoja === "zonas" ? "la primera zona" : hoja === "motivos" ? "el primer motivo" : "la primera área"}.
            </div>
          )}

          {filas.map((x) => {
            const n = hoja === "areas" ? usosArea(x.id) : usos(x.id);
            return (
              <div className={"fila dos" + (x.activo ? "" : " apagada")
                              + (escogidas.has(x.id) ? " ac-m-puesta" : "")} key={x.id}>
                <div>
                  <div className="tit">
                    {/* LA QUE NO SE PUEDE BORRAR LLEVA UN HUECO DEL
                        MISMO ANCHO. Sin él, su nombre empieza treinta
                        píxeles a la izquierda de los demás y la lista
                        se lee torcida — parece un error de la pantalla
                        y no la regla que es. */}
                    {puedeEditar && n > 0 && <span className="ac-m-hueco" aria-hidden />}
                    {puedeEditar && n === 0 && (
                      <label className="ac-m-caja">
                        <input type="checkbox" checked={escogidas.has(x.id)}
                               aria-label={`Escoger ${x.nombre}`}
                               onChange={() => setEscogidas((a) => {
                                 const s = new Set(a);
                                 s.has(x.id) ? s.delete(x.id) : s.add(x.id);
                                 return s;
                               })} />
                      </label>
                    )}
                    {x.nombre}
                  </div>
                  <div className="meta">
                    <code className="clave">{x.id}</code>
                    <span>·</span>
                    <span>{x.sub}</span>
                    {x.critico && <><span>·</span><span className="eti alta">CRÍTICO</span></>}
                    {!x.activo && <><span>·</span><span className="eti anulada">DESACTIVADA</span></>}
                    {n > 0 && (
                      <>
                        <span>·</span>
                        <span>{n} {hoja === "areas" ? "cosas colgando" : n === 1 ? "acción" : "acciones"}</span>
                      </>
                    )}
                  </div>

                  {editando === x.id && (
                    <div className="panel">
                      <Campos hoja={hoja} f={f} setF={setF} areas={areas} />
                      <div className="acciones-panel">
                        <button type="button" className="btn si" disabled={mandando || !puedeGuardar}
                                onClick={() => guardar(x.id)}>
                          {mandando ? "Guardando…" : "Guardar"}
                        </button>
                        <button type="button" className="btn plano" onClick={() => setEditando(null)}>
                          Cancelar
                        </button>
                      </div>
                    </div>
                  )}

                </div>

                {puedeEditar && (
                  <div className="der">
                    <div className="par">
                      <button type="button" className="btn" onClick={() => abrirEditar(x.id)}>
                        {editando === x.id ? "Cerrar" : "Editar"}
                      </button>
                      <button type="button" className={"btn" + (x.activo ? "" : " si")}
                              onClick={() => alternar(x.id, x.activo)}>
                        {x.activo ? "Desactivar" : "Activar"}
                      </button>
                      {n === 0 ? (
                        <button type="button" className="btn mal" disabled={mandando}
                                onClick={() => borrar(x.id, x.nombre)}>
                          Eliminar
                        </button>
                      ) : (
                        <span className="nota-chica" title="Borrarla se llevaría el histórico">
                          no se puede borrar, ya se usó
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </>
  );
}

const TEXTO: Record<Hoja, string> = {
  zonas:
    "El código es el que va pegado en la pared y el que lee la cámara: por eso no se puede " +
    "cambiar. Desactivar la quita de la lista de reportar sin tocar el histórico; eliminar solo " +
    "se puede si nunca se usó.",
  motivos:
    "La lista cerrada de lo que se puede reportar. Es lista y no texto libre porque la " +
    "reincidencia se cuenta por motivo y zona: “estibas mal apiladas” escrito de catorce maneras " +
    "no se cuenta nunca como tres veces lo mismo. El detalle de cada caso sigue siendo libre.",
  areas:
    "Son los renglones de “Cumplimiento por área” del tablero. Cada zona y cada motivo apuntan " +
    "a una; por eso un área con cosas colgando no se puede borrar.",
  equipos:
    "Opcional, y normalmente vacío. Sirve para pasarle una acción a un operador logístico " +
    "cuando todavía no se sabe a quién de adentro le va a tocar: el OL responde, y ya le " +
    "pondrán nombre. Si el contratista tiene usuario propio en la plataforma, se le asigna " +
    "directo como a cualquiera y esto no hace falta. Nace vacío a propósito: los contratistas " +
    "de un centro de distribución son un dato, no parte del programa.",
};

/** Los campos del formulario, compartidos entre crear y editar. */
function Campos({ hoja, f, setF, areas, nuevo }: {
  hoja: Hoja;
  f: { clave: string; nombre: string; proceso: string; area: string; critico: boolean };
  setF: (v: { clave: string; nombre: string; proceso: string; area: string; critico: boolean }) => void;
  areas: Area[];
  nuevo?: boolean;
}) {
  return (
    <>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 9 }}>
        {hoja === "zonas" && (
          <div>
            <label>CÓDIGO {nuevo ? "(el del QR)" : "· no se puede cambiar"}</label>
            <input value={f.clave} placeholder="AG01-PAS-05" disabled={!nuevo}
                   onChange={(e) => setF({ ...f, clave: e.target.value.toUpperCase() })} />
          </div>
        )}
        <div>
          <label>NOMBRE</label>
          <input value={f.nombre}
                 placeholder={hoja === "zonas" ? "Pasillo 5" : hoja === "motivos" ? "Estiba sin envolver" : "Calidad"}
                 onChange={(e) => setF({ ...f, nombre: e.target.value })} />
        </div>
        {hoja === "zonas" && (
          <div>
            <label>PROCESO</label>
            <input value={f.proceso} placeholder="Picking"
                   onChange={(e) => setF({ ...f, proceso: e.target.value })} />
          </div>
        )}
        {hoja !== "areas" && (
          <div>
            <label>ÁREA</label>
            <select value={f.area} onChange={(e) => setF({ ...f, area: e.target.value })}>
              {hoja === "motivos" && <option value="">Sin área fija</option>}
              {areas.map((a) => <option key={a.clave} value={a.clave}>{a.nombre}</option>)}
            </select>
          </div>
        )}
      </div>

      {hoja === "motivos" && (
        <label style={{ display: "flex", gap: 9, alignItems: "center", cursor: "pointer" }}>
          <input type="checkbox" checked={f.critico} style={{ width: 18, height: 18, minHeight: 0 }}
                 onChange={(e) => setF({ ...f, critico: e.target.checked })} />
          <span style={{ letterSpacing: 0, textTransform: "none", fontSize: 12.5 }}>
            Crítico — propone prioridad alta al reportarlo. Se puede bajar, pero hay que hacerlo
            a propósito.
          </span>
        </label>
      )}

      {hoja === "zonas" && (
        <div className="aviso">
          El área es la que agrupa el tablero: una acción reportada en esta zona va a contar para{" "}
          <b>{areas.find((a) => a.clave === f.area)?.nombre ?? "—"}</b>, no para el área del motivo.
        </div>
      )}
    </>
  );
}

