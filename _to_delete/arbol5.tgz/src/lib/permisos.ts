/**
 * QUÉ PUEDE HACER QUIEN ENTRÓ.
 *
 * Los permisos son DATOS: viven en las tablas roles y rol_permisos, y se
 * editan desde /admin/roles. Aquí solo se leen, una vez por pantalla, y
 * se contestan tres preguntas:
 *
 *   nivel(ruta)       → 'ninguno' | 'ver' | 'editar'
 *   puedeVer(ruta)    → ¿aparece en el menú y deja entrar?
 *   puedeEditar(ruta) → ¿salen los botones de guardar?
 *
 * LA CLAVE ES LA RUTA de la sección (/sider/transito), la misma de
 * src/modulos/registro.ts. Un segundo identificador en paralelo sería un
 * segundo sitio donde equivocarse.
 *
 * OJO: esto decide qué se DIBUJA. Quien de verdad manda es la base —RLS
 * y las funciones con security definer—, porque a una pantalla escondida
 * se llega igual escribiendo la URL. Las dos capas dicen lo mismo, pero
 * la que protege es la de abajo.
 */

import { cache } from "react";
import { createClient } from "@/lib/supabase/server";
import { usuarioActual } from "@/lib/sesion";
import { MODULOS, type Modulo } from "@/modulos/registro";

export type Nivel = "ninguno" | "ver" | "editar";

export type Permisos = {
  /** La clave del rol: 'admin', 'porteria'… */
  rol: string;
  /** El nombre para mostrar. */
  nombreRol: string;
  /** Puede todo y administra roles y usuarios. */
  manda: boolean;
  nivel: (ruta: string) => Nivel;
  puedeVer: (ruta: string) => boolean;
  puedeEditar: (ruta: string) => boolean;
  /** Los módulos que esta persona puede ver, ya filtrados. */
  modulos: Modulo[];
  /**
   * Si las tablas de roles todavía no existen. Sin esto, un proyecto al
   * que le falta correr 02-roles.sql dejaría a todo el mundo sin nada y
   * nadie sabría por qué.
   */
  falta: boolean;
};

/** Todo cerrado: lo que se devuelve cuando no hay sesión. */
const NADA: Permisos = {
  rol: "", nombreRol: "", manda: false,
  nivel: () => "ninguno", puedeVer: () => false, puedeEditar: () => false,
  modulos: [], falta: false,
};

/**
 * UNA SOLA VEZ POR PANTALLA, no una por quien pregunte.
 *
 * Esto lo llaman el armazón (para dibujar el menú) y la página (para
 * saber si salen los botones de guardar), y son cuatro consultas cada
 * vez: quién entró, su perfil, los roles y los permisos. Sin cache() se
 * pagaban ocho para pintar una pantalla, y las cuatro segundas
 * contestaban exactamente lo mismo que las cuatro primeras.
 *
 * cache() dura lo que dura ARMAR ESA PÁGINA. La petición siguiente
 * vuelve a preguntar, así que un cambio de rol se ve en la pantalla
 * siguiente y no queda pegado.
 */
export const misPermisos = cache(async function misPermisos(): Promise<Permisos> {
  const supabase = await createClient();
  const user = await usuarioActual();
  if (!user) return NADA;

  const [perfilR, rolesR, permisosR] = await Promise.all([
    supabase.from("perfiles").select("rol, activo, permisos_extra").eq("id", user.id).single(),
    supabase.from("roles").select("clave, nombre, manda"),
    supabase.from("rol_permisos").select("rol, seccion, nivel"),
  ]);

  const rol = (perfilR.data?.rol as string) ?? "operador";
  /* LOS PERMISOS DE ESTA PERSONA EN PARTICULAR, encima de los de su rol.
     Existen para la excepción: el de portería que además revisa el
     maestro. Sin esto habría que inventarle un rol para él solo, y la
     lista de roles se vuelve una lista de personas.
     MANDAN SOBRE EL ROL, hacia arriba y hacia abajo. Antes solo sumaban
     —«quitar se hace en el rol»— y eso obligaba a inventarle un rol
     propio a la persona que necesita ver UNA pantalla menos que sus
     compañeros, que es justo lo que los roles venían a evitar. Ahora lo
     que se le pone a una persona en /admin/usuarios es lo que vale para
     esa pantalla, y lo que no se le toca sigue saliendo de su rol.

     Si la columna todavía no existe —falta correr 03-usuarios.sql—
     queda vacío y todo sigue igual. */
  const extra = (perfilR.data as { permisos_extra?: Record<string, Nivel> } | null)
    ?.permisos_extra ?? {};

  /* Si las tablas no están, se cae del lado de ANTES: admin y supervisor
     editan, el resto mira. Es lo que hacía es_editor() y evita que un
     proyecto a medio migrar quede inservible. Se avisa con falta:true
     para que la pantalla lo diga en vez de que alguien se pregunte por
     qué no ve el menú. */
  if (rolesR.error || permisosR.error) {
    const viejo = rol === "admin" || rol === "supervisor";
    const nivel = (): Nivel => (viejo ? "editar" : "ver");
    return {
      rol, nombreRol: rol, manda: rol === "admin",
      nivel, puedeVer: () => true, puedeEditar: () => viejo,
      modulos: MODULOS.filter((m) => m.activo && !m.oculto),
      falta: true,
    };
  }

  const suRol = (rolesR.data ?? []).find((r) => r.clave === rol);
  const manda = !!suRol?.manda;

  const mapa = new Map<string, Nivel>();
  for (const p of (permisosR.data ?? []) as { rol: string; seccion: string; nivel: Nivel }[]) {
    if (p.rol === rol) mapa.set(p.seccion, p.nivel);
  }

  /* LO DE LA PERSONA MANDA; lo que no se le tocó sale de su rol.
     `extra[ruta]` puede valer "ninguno" a propósito: es cómo se le quita
     a una sola persona una pantalla que su rol sí da.

     UN ROL QUE ADMINISTRA LA PLATAFORMA SIGUE VIÉNDOLO TODO, y eso va
     ANTES que cualquier cosa suelta. No es un descuido: si se le pudiera
     quitar Administración a un administrador, el último que quedara
     podría encerrarse afuera y ya nadie podría devolvérselo. Quien manda
     entra siempre; para que alguien deje de mandar se le cambia el rol,
     que es una decisión visible. */
  const nivel = (ruta: string): Nivel => {
    if (manda) return "editar";
    const suyo = extra[ruta];
    if (suyo) return suyo;
    return mapa.get(ruta) ?? "ninguno";
  };
  const puedeVer = (ruta: string) => nivel(ruta) !== "ninguno";
  const puedeEditar = (ruta: string) => nivel(ruta) === "editar";

  /* Un módulo se ve si se puede ver ALGUNA de sus secciones. Mostrar un
     módulo cuyas cinco pantallas están cerradas es prometer una puerta
     que no abre. */
  const modulos = MODULOS.filter((m) => {
    if (!m.activo || m.oculto) return false;
    return m.secciones.some((s) => puedeVer(s.ruta)) || puedeVer(m.ruta);
  });

  return {
    rol, nombreRol: suRol?.nombre ?? rol, manda,
    nivel, puedeVer, puedeEditar, modulos, falta: false,
  };
});

/**
 * Adónde lleva la tarjeta de un módulo PARA ESTA PERSONA.
 *
 * Tres intentos, en orden: la pantalla que el módulo declara como
 * entrada, su ruta base, y —si ninguna de las dos le está abierta— la
 * primera sección que sí. Ese tercer caso no es teórico: hoy la tarjeta
 * llevaba siempre a la ruta base, así que alguien con permiso para
 * Certificar pero no para la Fuente principal tocaba el módulo y caía en
 * una pantalla que no puede abrir.
 */
export function entradaDe(m: Modulo, p: Permisos): string {
  if (m.entrada && p.puedeVer(m.entrada)) return m.entrada;
  if (p.puedeVer(m.ruta)) return m.ruta;
  return m.secciones.find((s) => p.puedeVer(s.ruta))?.ruta ?? m.ruta;
}

/** Las secciones de un módulo que esta persona puede ver. */
export function seccionesVisibles(m: Modulo, p: Permisos) {
  return m.secciones.filter((s) => p.puedeVer(s.ruta));
}
