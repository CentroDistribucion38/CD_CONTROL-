import { abierto, dueno } from "@/lib/acceso";
import { armarPanel } from "@/lib/datos";
import { Codigo } from "./Codigo";
import { Consumo } from "./Consumo";

export const dynamic = "force-dynamic";

export default async function Page() {
  const d = await dueno();
  if (!(d.ok && (await abierto(d.id)))) return <Codigo />;
  return <Consumo panel={await armarPanel()} />;
}
