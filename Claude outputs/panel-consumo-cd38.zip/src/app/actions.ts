"use server";

import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { abrir, cerrar, codigoCorrecto, dueno } from "@/lib/acceso";

/** Freno por dirección: 5 intentos fallidos y se bloquea 15 minutos (en memoria; por instancia, como ayuda extra al código largo). */
const fallos = new Map<string, { n: number; hasta: number }>();

export async function entrar(_: { mal?: boolean } | null, datos: FormData): Promise<{ mal?: boolean }> {
  const d = await dueno();
  const h = await headers();
  const ip = (h.get("x-forwarded-for") ?? "").split(",")[0].trim() || "?";
  const f = fallos.get(ip);
  if (f && f.n >= 5 && f.hasta > Date.now()) return { mal: true };
  if (!d.ok) return { mal: true };
  if (!codigoCorrecto(String(datos.get("codigo") ?? ""))) {
    fallos.set(ip, { n: (f && f.hasta > Date.now() ? f.n : 0) + 1, hasta: Date.now() + 15 * 60_000 });
    await new Promise((r) => setTimeout(r, 1500));   // frena el probar códigos uno tras otro
    return { mal: true };
  }
  fallos.delete(ip);
  await abrir(d.id);
  redirect("/");
}

export async function salir() {
  await cerrar();
  redirect("/");
}
