import type { Metadata, Viewport } from "next";
import "./consumo.css";

export const metadata: Metadata = { title: "CD38 · consumo", robots: { index: false, follow: false, nocache: true } };
export const viewport: Viewport = { width: "device-width", initialScale: 1 };

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body style={{ margin: 0 }}><div className="ci">{children}</div></body>
    </html>
  );
}
