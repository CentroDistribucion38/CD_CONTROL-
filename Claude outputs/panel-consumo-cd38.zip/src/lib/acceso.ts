/**
 * LA PUERTA DEL PANEL EXTERNO.
 *
 * Una sola llave: el código (variable PANEL_CODIGO). Al acertar se deja una cookie firmada que dura
 * 30 minutos. Sin PANEL_CODIGO puesto, la puerta queda cerrada para todos.
 * No hay cuentas ni base propia: lo que se muestra se lee de Supabase y de Vercel con tus tokens.
 */
import "server-only";
import { createHmac, createHash, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

const COOKIE = "__ci";
export const VIDA_S = 30 * 60;

/** Aquí no hay cuentas: la única llave es el código. Una sola «persona»: el dueño. */
export async function dueno(): Promise<{ ok: boolean; id: string }> {
  return { ok: !!process.env.PANEL_CODIGO, id: "dueno" };
}

const firma = (id: string, exp: number) =>
  createHmac("sha256", process.env.PANEL_CODIGO ?? "").update(`${id}.${exp}`).digest("hex");

const igual = (a: string, b: string) => {
  const x = createHash("sha256").update(a).digest(), y = createHash("sha256").update(b).digest();
  return timingSafeEqual(x, y);
};

export const codigoCorrecto = (txt: string) => !!process.env.PANEL_CODIGO && igual(txt.trim(), process.env.PANEL_CODIGO.trim());

export async function abierto(id: string): Promise<boolean> {
  const c = (await cookies()).get(COOKIE)?.value;
  if (!c) return false;
  const [exp, f] = c.split(".");
  const n = Number(exp);
  if (!n || !f || n < Date.now()) return false;
  return igual(f, firma(id, n));
}

export async function abrir(id: string) {
  const exp = Date.now() + VIDA_S * 1000;
  (await cookies()).set(COOKIE, `${exp}.${firma(id, exp)}`, {
    httpOnly: true, secure: true, sameSite: "strict", path: "/", maxAge: VIDA_S,
  });
}

export async function cerrar() {
  (await cookies()).set(COOKIE, "", { httpOnly: true, secure: true, sameSite: "strict", path: "/", maxAge: 0 });
}
