# Panel de consumo de CONTROL (externo)

Panel privado y aparte de CONTROL: dice cómo va el consumo de **Supabase** (base de datos, archivos,
usuarios, peticiones, tablas y consultas más pesadas) y de **Vercel** (consumo del mes y cómo cerraría)
frente a lo que incluye tu plan. No lo ve nadie de CONTROL, no usa su base y se abre solo con un código.

## Subirlo (una sola vez)
1. Crea un repositorio nuevo y privado en GitHub (por ejemplo `panel-consumo-cd38`) y sube esta carpeta:
   `git init && git add -A && git commit -m "Panel de consumo" && git branch -M main && git remote add origin <URL> && git push -u origin main`
2. En Vercel: *Add New → Project*, escoge ese repositorio. En *Environment Variables* pon las de `.env.example`.
3. *Deploy*. Para verlo con datos de muestra antes de poner los tokens, usa `PANEL_DEMO=1`.

## Seguridad
- El código (`PANEL_CODIGO`) es la única llave: hazlo largo (12 o más caracteres). Tras 5 fallos desde una
  misma dirección se bloquea 15 minutos.
- Los tokens viven solo como variables de Vercel de ESTE proyecto (no en CONTROL).
- La pantalla no se indexa en buscadores ni se guarda en caché.
- El token de Supabase maneja tu cuenta: si lo ves expuesto en algún sitio, revócalo y crea otro.
